<?php
session_start();
include_once("../db_connection/connect_db.php");
if($_POST){
mysqli_query($conn,"INSERT INTO school(school_name,school_shortname,created_by,school_created,school_updated) 
VALUES ('".$_POST['school-name']."','".$_POST['school-shortname']."','".$_POST['created-by']."', CURTIME(),CURTIME())");

}
?>
