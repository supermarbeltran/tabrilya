<?php
session_start();
include_once("../db_connection/connect_db.php");
if($_POST){
		
		$date = htmlentities($_POST['create-batch-date']);
		if( empty($date) ) {
			fail('Please provide your Password.');
		}
		
	   $query = "SELECT * from admission_schedule where admission_date = '$date'";
		
	   $result = mysqli_query($conn,$query);
				
		if(mysqli_num_rows($result) == 0) {
		
			mysqli_query($conn,"INSERT INTO admission_schedule(admission_date,created_by,date_created,date_updated) VALUES ('".$date."','".$_SESSION['user_id']."',CURDATE(),CURDATE())");
			$schedID = mysqli_fetch_assoc(mysqli_query($conn,$query));
			$msg = "/tabrilya/view-applicant-list.php?admission_schedule_id=".$schedID['admission_schedule_id'];
			success($msg);
			 
		} else {
			fail("Admission Date Already exist");
		}
		exit;
	
}
	function fail($message) {
		die(json_encode(array('status' => 'fail', 'message' => $message)));
	}
	function success($message) {
		die(json_encode(array('status' => 'success', 'message' => $message)));
	}
?>
