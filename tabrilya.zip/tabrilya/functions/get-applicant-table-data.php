						<?php
						session_start();
						include_once("../db_connection/connect_db.php");
									$applicant_query = mysqli_query($conn,"SELECT applicant_id,school_id,course_id,applicant_exam_no,concat(applicant_fname,' ',applicant_lname) as applicant_name from applicant_info WHERE admission_schedule_id=".$_POST['admission_schedule_id']." ORDER BY applicant_id desc" );
									$rowNum = 0;
									while($applicant_row = mysqli_fetch_array($applicant_query)){
										$rowNum++;
										$school_row = mysqli_fetch_array(mysqli_query($conn,"SELECT school_shortname FROM school WHERE school_id=".$applicant_row['school_id']));
										$course_row = mysqli_fetch_array(mysqli_query($conn,"SELECT course_shortname FROM course WHERE course_id=".$applicant_row['course_id']));
										echo "<tr>
										<td>".$rowNum.".</td>
										<td>".$applicant_row['applicant_exam_no']."</td>
										<td>".$applicant_row['applicant_name']."</td>
										<td>".$course_row['course_shortname']."</td>
										<td>".$school_row['school_shortname']."</td>";
										$score_q = mysqli_query($conn,"SELECT score from scores WHERE applicant_id=".$applicant_row['applicant_id']);
										while($score_row = mysqli_fetch_array($score_q)){
											echo "<td>".$score_row['score']."</td>";
										}
										echo "<td>
										<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_applicant(".$applicant_row['applicant_id'].")'><i class='fa fa-edit fa-fw'></i></span>
										<a href='applicant-result.php?applicant_id=".$applicant_row['applicant_id']."&admission_schedule_id=".$_POST['admission_schedule_id']."'><span title='Analyse' class='btn btn-primary btn-sm btn-flat'><i class='fa fa- fa-lightbulb-o fa-fw'></i></span></a>
										</td>";
										echo "</tr>";
									}

						?>