<?php
session_start();
include_once("../db_connection/connect_db.php");

if($_POST){
	$query = "UPDATE `school` SET `school_name` = '".$_POST['school-name']."', `school_shortname` = '".$_POST['school-shortname']."', `school_updated` = CURRENT_TIME WHERE `school_id` = '".$_POST['school-id']."' ";
	mysqli_query($conn,$query);
}
?>