<?php
session_start();
include_once("../db_connection/connect_db.php");
?>	
							<thead>			
							<tr class="teal teal darken-3 white-text">
							  <th>No.</th>
							  <th>School Name</th>
							  <th>Created by</th>
							  <th>Action</th>
							</tr>
							</thead>
								<tbody>
								<?php
											$school_query = mysqli_query($conn,"SELECT * FROM school");
											$rowNum = 0;
											while($school_row = mysqli_fetch_array($school_query)){
											$account_row = mysqli_fetch_array(mysqli_query($conn,"SELECT user_username FROM accounts WHERE user_id=".$school_row['created_by']));
											$rowNum++;
												echo "<tr>
												<td>".$rowNum.".</td>
												<td>".$school_row['school_name']." <b>(".$school_row['school_shortname'].")</b></td>
												<td>".($_SESSION['username']==$account_row['user_username']?"<b>(me)</b> ":"").$account_row['user_username']."</td>
												<td>
												<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_school(".$school_row['school_id'].")'><i class='fa fa-edit fa-fw'></i></span>
												</td>";
												echo "</tr>";
											}

								?>
								</tbody>