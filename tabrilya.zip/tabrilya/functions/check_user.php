<?php
session_start();
include_once("../db_connection/connect_db.php");

if($_POST){
		
		$pass = htmlentities($_POST['password']);
		$username = $_POST['username'];
		if( empty($pass) ) {
			fail('Please provide your Password.');
		}
		
	   $query = "SELECT * from accounts where user_username = '$username' AND user_password = '".md5(mysqli_real_escape_string($conn,$pass))."'";
		
	   $result = mysqli_query($conn,$query);
				
		if(mysqli_num_rows($result) == 1) {
		
		$row = mysqli_fetch_assoc(mysqli_query($conn,$query));
		
		    $_SESSION['cps_pass'] = md5($pass);
		    $_SESSION['username'] = $username;
		    $_SESSION['user_id'] = $row['user_id'];
		    $_SESSION['user'] = $row['user_full_name'];
		    $_SESSION['user_type'] = $row['user_type'];
			$msg = "/tabrilya/";
			success($msg);
			 
		} else {
			fail("Invalid Credentials, Please try again");
		}
		exit;
	
}


	function fail($message) {
		die(json_encode(array('status' => 'fail', 'message' => $message)));
	}
	function success($message) {
		die(json_encode(array('status' => 'success', 'message' => $message)));
	}
?>