<?php
session_start();
include_once("../db_connection/connect_db.php");
$result = mysqli_query($conn,"SELECT * from school WHERE school_id = ".$_POST['school_id']);
$school_row = mysqli_fetch_assoc($result);
?>												
				<!-- School Name -->
					<div class="form-group">
						 <label >School</label>
							<input type="text" class="form-control" name="school-name" value="<?php echo $school_row['school_name'];?>" id="" placeholder="Complete Name" required>
					</div>
				<!-- /.form group -->
				
				<!-- School ShortName -->
					<div class="form-group">
						 <label >School Acronym</label>
							<input type="text" class="form-control" name="school-shortname" value="<?php echo $school_row['school_shortname'];?>" id="" placeholder="Acronym" required>
					</div>
				<!-- /.form group -->
				  
				<input type="text" name="school-id" value="<?php echo $_POST['school_id'];?>" style="display: none;">
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					  <input type="password" class="form-control" name="user-password" id="school-edit-user-password" placeholder="Password" required>
                </div>
				<!-- /.Password -->

			   <div class="school-alert alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>
			   
			   <div class="school-success-alert alert alert-success alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-check"></i> Successful</h4> <span></span>
			   </div>	