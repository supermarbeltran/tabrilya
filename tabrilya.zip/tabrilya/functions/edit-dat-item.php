<?php
session_start();
include_once("../db_connection/connect_db.php");

if($_POST){

	$dat_query = mysqli_query($conn,"SELECT * FROM dat ORDER BY dat_id");
	while($dat_row = mysqli_fetch_array($dat_query)){
		$query = "UPDATE `dat` SET `dat_items` = '".$_POST['dat_'.$dat_row['dat_id']]."' WHERE `dat_id` = '".$dat_row['dat_id']."' ";
		mysqli_query($conn,$query);
	}
	header("location: ../view-dat.php");
}
?>