<?php
session_start();
include_once("../db_connection/connect_db.php");

if($_POST){
	$query = "UPDATE `course` SET `course_name` = '".$_POST['course-name']."', `course_shortname` = '".$_POST['course-shortname']."', `department_id` = '".$_POST['course-department-id']."' WHERE `course_id` = '".$_POST['course-id']."' ";
	mysqli_query($conn,$query);
}
?>