<?php
session_start();
include_once("../db_connection/connect_db.php");
?>	
							<thead>			
							<tr class="teal teal darken-3 white-text">
							  <th>No.</th>
							  <th>Department</th>
							  <th>Course Name</th>
							  <th>Action</th>
							</tr>
							</thead>
								<tbody>
								<?php
											$course_query = mysqli_query($conn,"SELECT * FROM course ORDER BY department_id");
											$rowNum = 0;
											while($course_row = mysqli_fetch_array($course_query)){
											$department_name_row = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM department WHERE department_id=".$course_row['department_id']));
												$rowNum++;
												echo "<tr>
												<td>".$rowNum.".</td>
												<td>".$department_name_row['department_shortname']."</td>
												<td>".$course_row['course_name']."<b> (".$course_row['course_shortname'].")</b></td>
												<td>
												<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_course(".$course_row['course_id'].")'><i class='fa fa-edit fa-fw'></i></span>
												</td>";
												echo "</tr>";
											}

								?>
								</tbody>