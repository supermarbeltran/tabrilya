<?php
session_start();
include_once("../db_connection/connect_db.php");
$result = mysqli_query($conn,"SELECT * from department WHERE department_id = ".$_POST['department_id']);
$department_row = mysqli_fetch_assoc($result);
?>

				<!-- Department Name -->
					<div class="form-group">
						 <label >Department</label>
							<input type="text" class="form-control" name="department-name" value="<?php echo $department_row['department_name'];?>" id="" placeholder="Complete Name e.g. Department of . ." required>
					</div>
				<!-- /.form group -->
				
				<!-- Department ShortName -->
					<div class="form-group">
						 <label >Department Acronym</label>
							<input type="text" class="form-control" name="department-shortname" value="<?php echo $department_row['department_shortname'];?>" id="" placeholder="Acronym" required>
					</div>
				<!-- /.form group -->
				  
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					  <input type="password" class="form-control" name="user-password" id="department-user-password" placeholder="Password" required>
                </div>
				<!-- /.Password -->

				
				<input type="text" name="department_id" value="<?php echo $_POST['department_id'];?>" style="display:none;">
				
				
			   <div class="department-alert alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>	
			
			   <div class="department-success-alert alert alert-success alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-check"></i> Successful!</h4> <span></span>
			   </div>	
