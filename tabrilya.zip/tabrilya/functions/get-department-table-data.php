<?php
session_start();
include_once("../db_connection/connect_db.php");
?>							<thead>			
							<tr class="teal teal darken-3 white-text">
							  <th>No.</th>
							  <th>Department Name</th>
							  <th>Action</th>
							</tr>
							</thead>
								<tbody>
								<?php
											$department_query = mysqli_query($conn,"SELECT * FROM department" );
											$rowNum = 0;
											while($department_row = mysqli_fetch_array($department_query)){
												$rowNum++;
												echo "<tr>
												<td>".$rowNum.".</td>
												<td>".$department_row['department_name']."<b> (".$department_row['department_shortname'].")</b></td>
												<td>
												<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_department(".$department_row['department_id'].")'><i class='fa fa-edit fa-fw'></i></span>
												</td>";
												echo "</tr>";
											}

								?>
								</tbody>