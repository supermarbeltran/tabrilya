<?php
session_start();
include_once("../db_connection/connect_db.php");

if($_POST){
	$query = "UPDATE `department` SET `department_name` = '".$_POST['department-name']."', `department_shortname` = '".$_POST['department-shortname']."' WHERE `department_id` = '".$_POST['department_id']."' ";
	mysqli_query($conn,$query);
}
?>