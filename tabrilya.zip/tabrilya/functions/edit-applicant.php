<?php
session_start();
include_once("../db_connection/connect_db.php");

if($_POST){
		
		if( empty($_POST) ) {
			fail('Please provide inputs.');
		}
	   $columns_applicant = array('applicant_exam_no','course_id','applicant_fname','applicant_lname','applicant_mname','school_id','applicant_gender','applicant_updated');
	   $query = "UPDATE `applicant_info` SET ".getSetValues($columns_applicant)." WHERE `applicant_info`.`applicant_id` =".$_POST['applicant_id'];

		if($result = mysqli_query($conn,$query)) {

			$dat_result = mysqli_query($conn,"SELECT * from dat ORDER BY dat_id");
			while($dat_row = mysqli_fetch_assoc($dat_result)){
			   $q = "UPDATE `scores` SET score = ".$_POST['applicant-dat_'.$dat_row['dat_id'].'']." WHERE applicant_id = ".$_POST['applicant_id']." AND dat_id = ".$dat_row['dat_id']." ";
			   mysqli_query($conn,$q);
			}
			$msg = "Updated successfully!";
			success($msg);
			 
		} else {
			fail("Invalid Input, Please try again");
		}
	$msg = "Updated successfully!";
			success($msg);
	
}

	function getSetValues($array){
		$value = ""; $KEY = array_keys($_POST);
		for($i = 0; $i < sizeof($array); $i++){
			if($i == (sizeof($array)-1)) {
			$value = $value."`".$array[$i]."` = CURTIME() ";
			}
			else{
			$value = $value."`".$array[$i]."` = '".$_POST[$KEY[$i]]."', ";
			}
	}
	return $value;
	}
	function fail($message) {
		die(json_encode(array('status' => 'fail', 'message' => $message)));
	}
	function success($message) {
		die(json_encode(array('status' => 'success', 'message' => $message)));
	}
?>