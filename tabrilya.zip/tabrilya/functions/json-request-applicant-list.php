<?php
session_start();
include_once("../db_connection/connect_db.php");

$aColumns = array( "applicant_id","applicant_exam_no", "concat(applicant_fname,' ',applicant_lname,' ',applicant_mname)");

	$sIndexColumn = "applicant_id";
	/* DB table to use */
	$sTable = "applicant_info";
	
	/* 
	 * Paging
	 */
	$sLimit = "";
	if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
	{
		$sLimit = "LIMIT ".mysql_real_escape_string( $_GET['iDisplayStart'] ).", ".
			mysql_real_escape_string( $_GET['iDisplayLength'] );
	}
	
	/*
	 * Ordering
	 */
	if ( isset( $_GET['iSortCol_0'] ) )
	{
		$sOrder = "ORDER BY  ";
		for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
		{
			if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
			{
				$sOrder .= $aColumns[ intval( $_GET['iSortCol_'.$i] ) ]."
				 	".mysql_real_escape_string( $_GET['sSortDir_'.$i] ) .", ";
			}
		}
		$sOrder = substr_replace( $sOrder, "", -2 );
		if ( $sOrder == "ORDER BY" )
		{
			$sOrder = "";
		}
	}
	
	 $results = array(
	 "sEcho" => intval($_GET['sEcho']),
	 "iTotalRecords" => 1,
	 "iTotalDisplayRecords" => 1,
	 "aaData"=> array()
	 );

	/* 
	 * Filtering
	 * NOTE this does not match the built-in DataTables filtering which does it
	 * word by word on any field. It's possible to do here, but concerned about efficiency
	 * on very large tables, and MySQL's regex functionality is very limited
	 */
	if ( $_GET['sSearch'] != "" )
	{
		$sWhere = "WHERE (";
		for ( $i=0 ; $i<count($aColumns) ; $i++ )
		{
			$sWhere .= $aColumns[$i]." LIKE '%".mysql_real_escape_string( $_GET['sSearch'] )."%' OR ";
		}
		$sWhere = substr_replace( $sWhere, "", -3 );
		$sWhere .= ')';
	}
	else $sWhere = "WHERE admission_schedule_id=".$_GET['admission_schedule_id'];
	
			$r = mysqli_query($conn,"SELECT applicant_id,applicant_exam_no,concat(applicant_fname,' ',applicant_lname,' ',applicant_mname) from applicant_info ".$sWhere." ".$sOrder." ".$sLimit);
			$applicant = mysqli_query($conn,"SELECT * from applicant_info ".$sWhere." ".$sOrder." ".$sLimit);
			while($row = mysqli_fetch_array($r)){
			$applicant_r = mysqli_fetch_array($applicant);
			
				$score_q = mysqli_query($conn,"SELECT score from scores WHERE applicant_id=".$applicant_r['applicant_id']);
				while($score_row = mysqli_fetch_array($score_q)){
					$row[] = $score_row['score'];
				}
				$results["aaData"][] = $row;
			}
		/* Data set length after filtering */
	$qry = mysqli_query($conn,"SELECT * from applicant_info ".$sWhere." ".$sOrder);
	$sQuery = "
		SELECT FOUND_ROWS()
	";
	$rResultFilterTotal = mysqli_query( $conn,$sQuery ) or die(mysql_error());
	$aResultFilterTotal = mysqli_fetch_array($rResultFilterTotal);
	$iFilteredTotal = $aResultFilterTotal[0];
	
	/* Total data set length */
	$sQuery = "
		SELECT COUNT(".$sIndexColumn.")
		FROM   $sTable
		WHERE admission_schedule_id=".$_GET['admission_schedule_id']."
	";
	$rResultTotal = mysqli_query( $conn,$sQuery ) or die(mysql_error());
	$aResultTotal = mysqli_fetch_array($rResultTotal);
	$iTotal = $aResultTotal[0];
	
	 $num_rows = count($results["aaData"]);
	 $results["iTotalRecords"] = $iTotal;
	 $results["iTotalDisplayRecords"] = $iFilteredTotal;
	 
echo json_encode($results);
?>
