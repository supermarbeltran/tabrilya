<?php
session_start();
include_once("../db_connection/connect_db.php");
if($_POST){
mysqli_query($conn,"INSERT INTO department(department_name,department_shortname,department_created,department_updated) 
VALUES ('".$_POST['department-name']."','".$_POST['department-shortname']."',CURTIME(),CURTIME())");

header("location: ../view-department-courses.php");
}
?>
