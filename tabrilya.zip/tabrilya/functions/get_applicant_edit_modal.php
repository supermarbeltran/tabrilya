<?php
session_start();
include_once("../db_connection/connect_db.php");
$result = mysqli_query($conn,"SELECT * from applicant_info WHERE applicant_id = ".$_POST['applicant_id']);
$applicant_row = mysqli_fetch_assoc($result);
?>
					<div class="col-sm-6">
							
								<!-- BOX Header -->
								<div class="box-header">
								  <h3 class="box-title"><span class="fa fa-user fa-fw"></span> Applicants Info</h3>
								</div>	

								<!-- Examinee Number -->
								   <div class="form-group col-sm-6">
									  <label>Examinee No.</label>
									  <input type="text" class="form-control" name="applicant-examinee-no" value="<?php echo $applicant_row['applicant_exam_no'];?>" id="" placeholder="Examinee No." required>
								   </div>
								<!-- /.form group -->

								<!-- Course Applied -->
								   <div class="form-group col-sm-6">
									  <label>Course Applied</label>
									  <select class="form-control select2" style="width: 100%;" name="applicant-course-applied" id="" placeholder="" required>
										<option value=""></option>
										<?php
										$course_q = "SELECT * from course ORDER BY department_id";
										$course_result = mysqli_query($conn,$course_q);
										while($course_row = mysqli_fetch_assoc($course_result)){
										echo"<option ".($course_row['course_id']==$applicant_row['course_id']?"selected='selected'":"")." value='".$course_row['course_id']."'>".$course_row['course_shortname']."</option>";
										}
										?>
									  </select>
								   </div>
								<!-- /.form group -->
								
								<!-- First Name -->
								   <div class="form-group col-sm-12">
									  <label for="">First Name</label>
									  <input type="text" class="form-control" name="applicant-fname" value="<?php echo $applicant_row['applicant_fname'];?>" id="" placeholder="First Name" required>
								   </div>
								<!-- /.form group -->

								<!-- First Name -->
								   <div class="form-group col-sm-12">
									  <label>Last Name</label>
									  <input type="text" class="form-control" name="applicant-lname" value="<?php echo $applicant_row['applicant_lname'];?>" id="Last Name" placeholder="Last Name" required>
								   </div>
								<!-- /.form group -->

								<!-- First Name -->
								   <div class="form-group col-sm-12">
									  <label >Middle Name/Initial</label>
									  <input type="text" class="form-control" name="applicant-mname" value="<?php echo $applicant_row['applicant_mname'];?>" id="" placeholder="Middle Name/Initial" required>
								   </div>
								<!-- /.form group -->

								
								<!-- School -->
								   <div class="form-group col-sm-7">
									  <label>School</label>
									  <select class="form-control select2" style="width: 100%;" name="applicant-school" id="" placeholder="" required>
										<option value=""></option>
										<?php
										$school_q = "SELECT * from school ORDER BY school_id";
										$school_result = mysqli_query($conn,$school_q);
										while($school_row = mysqli_fetch_assoc($school_result)){
										echo"<option ".($school_row['school_id']==$applicant_row['school_id']?"selected='selected'":"")." value='".$school_row['school_id']."'>".$school_row['school_name']."</option>";
										}
										?>
									  </select>								  

								  </div>
								<!-- /.form group -->
								
								  <div class="form-group col-sm-5">
										<label>Gender </label>
										<div>
											<label>
											  <input type="radio" name="applicant-gender" value="male" id="gender_1" class="minimal" <?php echo($applicant_row['applicant_gender']=='male'?'checked':'');?> required>
											  Male
											</label>
											<label>
											  <input type="radio" name="applicant-gender" value="female" id="gender_2" class="minimal" <?php echo($applicant_row['applicant_gender']=='female'?'checked':'');?> required>
											  Female
											</label>
										</div>
								  </div>

					</div>

					<div class="col-sm-6 well">

								<!-- BOX Header -->
								<div class="box-header">
								  <h3 class="box-title"><span class="fa fa-calculator fa-fw"></span> Scores</h3>
								</div>
								<?php
								
								$q = "SELECT * from dat ORDER BY dat_id";
								$r = mysqli_query($conn,$q);
								while($dat = mysqli_fetch_assoc($r)){
								$score_result = mysqli_query($conn,"SELECT score from scores WHERE dat_id=".$dat['dat_id']." AND applicant_id=".$_POST['applicant_id']." ");
								$score_row = mysqli_fetch_assoc($score_result);
								echo "
										<div class='form-group col-sm-6 text-center'>
										  <input type='text' class='knob' name='applicant-dat_".$dat['dat_id']."' value='".$score_row['score']."' data-min='0' data-max='".$dat['dat_items']."' data-width='90' data-angleArc='200' data-angleOffset='-100' data-height='50' data-fgColor='#00a65a' required>
										  <div class='knob-label'><b>".$dat['dat_name']."</b></div>
										</div>											   
								";
								}								
								
								?>							

					</div>
					<input type="text" name="applicant_id" value="<?php echo $applicant_row['applicant_id'];?>" style="display:none;">

			<div class="col-sm-12">
			   <div class="success-add-applicant-alert alert alert-success alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-check"></i> Success!</h4> <span></span>
			   </div>	
			</div>
			
<script>

  //Initialize Select2 Elements
    $('.select2').select2();
	
  //iCheck
$(function () {
$('#gender_1, #gender_2').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
 /* jQueryKnob */
 $(function () {
    /* jQueryKnob */

    $(".knob").knob({
      /*change : function (value) {
       //console.log("change : " + value);
       },
       release : function (value) {
       console.log("release : " + value);
       },
       cancel : function () {
       console.log("cancel : " + this.value);
       },*/
      draw: function () {

        // "tron" case
        if (this.$.data('skin') == 'tron') {

          var a = this.angle(this.cv)  // Angle
              , sa = this.startAngle          // Previous start angle
              , sat = this.startAngle         // Start angle
              , ea                            // Previous end angle
              , eat = sat + a                 // End angle
              , r = true;

          this.g.lineWidth = this.lineWidth;

          this.o.cursor
          && (sat = eat - 0.3)
          && (eat = eat + 0.3);

          if (this.o.displayPrevious) {
            ea = this.startAngle + this.angle(this.value);
            this.o.cursor
            && (sa = ea - 0.3)
            && (ea = ea + 0.3);
            this.g.beginPath();
            this.g.strokeStyle = this.previousColor;
            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sa, ea, false);
            this.g.stroke();
          }

          this.g.beginPath();
          this.g.strokeStyle = r ? this.o.fgColor : this.fgColor;
          this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sat, eat, false);
          this.g.stroke();

          this.g.lineWidth = 2;
          this.g.beginPath();
          this.g.strokeStyle = this.o.fgColor;
          this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
          this.g.stroke();

          return false;
        }
      }
    });
    /* END JQUERY KNOB */
 });
</script>