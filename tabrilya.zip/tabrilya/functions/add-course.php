<?php
session_start();
include_once("../db_connection/connect_db.php");
if($_POST){
mysqli_query($conn,"INSERT INTO course(course_name,course_shortname,department_id,course_created,course_updated) 
VALUES ('".$_POST['course-name']."','".$_POST['course-shortname']."','".$_POST['course-department-id']."', CURTIME(),CURTIME())");
	$row_course = mysqli_fetch_assoc(mysqli_query($conn,"SELECT course_id from course ORDER BY course_id DESC LIMIT 1"));
	$query_dat = mysqli_query($conn,"SELECT * from dat ORDER BY dat_id");
	while($row_dat = mysqli_fetch_assoc($query_dat)){
	mysqli_query($conn,"INSERT INTO course_requirement(score,course_id,dat_id) 
	VALUES ('".(100/7)."','".$row_course['course_id']."','".$row_dat['dat_id']."' )");
	}
}
?>
