<?php
session_start();
include_once("../db_connection/connect_db.php");
$result = mysqli_query($conn,"SELECT * from course WHERE course_id = ".$_POST['course_id']);
$course_row = mysqli_fetch_assoc($result);
?>						
			<!-- Course Applied -->
				<div class="form-group">
					<label>Course Department</label>
					<select class="form-control select2" style="width: 100%;" name="course-department-id" id="" placeholder="" required>
						<option value=""></option>
						<?php
						$department_q = "SELECT * from department ORDER BY department_id";
						$department_result = mysqli_query($conn,$department_q);
						while($department_row = mysqli_fetch_assoc($department_result)){
						echo"<option ".($course_row['department_id']==$department_row['department_id']?" selected='selected' ":"")." value='".$department_row['department_id']."'>".$department_row['department_name']."</option>";
						}
						?>
					</select>
				</div>
			<!-- /.form group -->
								
				<!-- Course Name -->
					<div class="form-group">
						 <label >Course</label>
							<input type="text" class="form-control" name="course-name" value="<?php echo $course_row['course_name'];?>" id="" placeholder="Complete Name e.g. (Bachelor of Science in Computer Science)" required>
					</div>
				<!-- /.form group -->
				
				<!-- Course ShortName -->
					<div class="form-group">
						 <label >Course Acronym</label>
							<input type="text" class="form-control" name="course-shortname" value="<?php echo $course_row['course_shortname'];?>" id="" placeholder="Acronym" required>
					</div>
				<!-- /.form group -->
				  
				  <input type="text" name="course-id" value="<?php echo $_POST['course_id'];?>" style="display: none;">
				  
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					  <input type="password" class="form-control" name="user-password" id="course-edit-user-password" placeholder="Password" required>
                </div>
				<!-- /.Password -->

			   <div class="course-alert alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>
			   
			   <div class="course-success-alert alert alert-success alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-check"></i> Successful</h4> <span></span>
			   </div>
			   

<script>
    $('.select2').select2();
</script>	