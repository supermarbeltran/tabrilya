<?php
session_start();
include_once("../db_connection/connect_db.php");

if($_POST){
		
		if( empty($_POST) ) {
			fail('Please provide inputs.');
		}
		
	   $query = "INSERT INTO applicant_info(applicant_exam_no,course_id,applicant_fname,applicant_lname,applicant_mname,school_id,applicant_gender,admission_schedule_id,applicant_created,applicant_updated)
	   VALUES (".getValues($_POST).",CURTIME(),CURTIME())";

		if($result = mysqli_query($conn,$query)) {
			//$msg = "/tabrilya/";
			//success($msg);
			$result_1 = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * from applicant_info ORDER BY applicant_id desc LIMIT 1"));
			
			$r = mysqli_query($conn,"SELECT * from dat ORDER BY dat_id");
			while($result_2 = mysqli_fetch_assoc($r)){
			   $q = "INSERT INTO scores(score,applicant_id,dat_id,user_id,score_created,score_updated)
			   VALUES ('".$_POST['applicant-dat_'.$result_2['dat_id'].'']."','".$result_1['applicant_id']."','".$result_2['dat_id']."','".$_SESSION['user_id']."',CURTIME(),CURTIME())";			
			   mysqli_query($conn,$q);
			}
			/* Total data set length */
			$sQuery = "
				SELECT COUNT(applicant_id)
				FROM   applicant_info
				WHERE admission_schedule_id = ".$_POST['admission_schedule_id']."
			";
			$rResultTotal = mysqli_query( $conn,$sQuery ) or die(mysql_error());
			$aResultTotal = mysqli_fetch_array($rResultTotal);
			$iTotal = $aResultTotal[0];
			//UPDATE NUMBER OF APPLICANTS
			mysqli_query($conn,"UPDATE `admission_schedule` SET `number_of_applicants` = $iTotal WHERE `admission_schedule`.`admission_schedule_id` = ".$_POST['admission_schedule_id']);
			//Message Successful
			$msg = "Applicant added successfully!";
			success($msg);
			 
		} else {
			fail("Invalid Input, Please try again");
		}
		exit;
	
}

	function getValues($array){
		$value = "";
		$arr = array_keys($array);
		for($i = 0; $i < sizeof($array); $i++){
			$value = $value."'".$array[$arr[$i]]."',";
			if($i==6){
			$value = $value.$array[$arr[sizeof($array)-1]];
			break;
			}
		}
		return $value;
	}
	function fail($message) {
		die(json_encode(array('status' => 'fail', 'message' => $message)));
	}
	function success($message) {
		die(json_encode(array('status' => 'success', 'message' => $message)));
	}
?>