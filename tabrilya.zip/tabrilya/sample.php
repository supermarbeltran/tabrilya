<!DOCTYPE html>
<html lang="en">
<html>
<head> 
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=0.5,user-scalable=no">
<link rel="stylesheet" href="css/colors.css">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
<title>Prototype Muna</title>
</head>

<body class="yellow lighten-5">
<div class="container">

<div class="col-md-10">
<?php
require_once('class/ahp.php');

$criteria_level1 = array ("IMPORTANCE");
$alternativeid_level1 = array ("TEST_1","TEST_2","TEST_3","TEST_4","TEST_5","TEST_6","TEST_7","TEST_8");
$alternative_level1 = array(
			array("2","4","1","2","5","3","1","8")
		);	 

$ahp_level1 = new AHP();
$ahp_level1->SetCriteria($criteria_level1);
$ahp_level1->SetAlternativeID($alternativeid_level1);
//$norm = $ahp->NormalizeAlternative($alternative);
$pw_result_level1 = $ahp_level1->PairWise($alternative_level1);
$pw_result_norm_level1 = $ahp_level1->NormalizePairwise($pw_result_level1);
$aggregates_level1 = $ahp_level1->AggregatePairwise($pw_result_norm_level1);
$ahp_rank_level1 = $ahp_level1->RankAggregate($aggregates_level1,-1);

echo "<h3>Level 1 Alternatives:</h3>";
$ahp_level1->PrintAlternative($alternative_level1);
//echo "Normalized Alternatives:<br>";
//$ahp->PrintAlternative($norm);
echo "<h3>Pairwise comparisons for given criterion:</h3>";
$ahp_level1->PrintPairWise($pw_result_level1);
echo "<h3>Normalized PairWise:</h3>";
$ahp_level1->PrintPairWise($pw_result_norm_level1);
echo "<h3>Aggregates:</h3>";
$ahp_level1->PrintAggregate($aggregates_level1);
echo "<h3>Ranking:</h3>";
$ahp_level1->PrintRanking($ahp_rank_level1);
?>
</div>

<div class="col-md-6">
<?php

$criteria = array ("TEST_1","TEST_2","TEST_3","TEST_4","TEST_5","TEST_6","TEST_7","TEST_8");
$alternativeid = array("COURSE_ID1","COURSE_ID2","COURSE_ID3");
$alternative = array(
			array("4","4","2"),
			array("3","1","0.5"),
			array("1","1","4"),
			array("1","1","2"),
			array("4","3","5"),
			array("5","2","1"),
			array("7","6","1"),
			array("3","6","3"),
		);	 

$ahp = new AHP();
$ahp->SetCriteria($criteria);
$ahp->SetAlternativeID($alternativeid);
//$norm = $ahp->NormalizeAlternative($alternative);
$pw_result = $ahp->PairWise($alternative);
$pw_result_norm = $ahp->NormalizePairwise($pw_result);
$aggregates = $ahp->AggregatePairwise_respectToLevel1($pw_result_norm,$ahp_rank_level1);
$ahp_rank = $ahp->RankAggregateLevel1($aggregates,-1);

echo "<h3>Level 2 Alternatives:</h3>";
$ahp->PrintAlternative($alternative);
//echo "Normalized Alternatives:<br>";
//$ahp->PrintAlternative($norm);
echo "<h3>Pairwise comparisons of alternatives with respect to criteria:</h3>";
$ahp->PrintPairWise($pw_result);
echo "<h3>Normalized PairWise:</h3>";
$ahp->PrintPairWise($pw_result_norm);
echo "<h3>Aggregates w/ respect to Level 1:</h3>";
$ahp->PrintAggregate($aggregates);
?>
</div>

<div class="col-md-2">
<?php
echo "<h3>Final Ranking:</h3>";
$ahp->PrintRanking($ahp_rank);
?>
</div>

</div>

</body>
</html>