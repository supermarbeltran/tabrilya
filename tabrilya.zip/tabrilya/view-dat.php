<?php
include_once("db_connection/connect_db.php");
session_start();
if(!isset($_SESSION['cps_pass'])){
	header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CSPC | CPS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Hover CSS -->
  <link rel="stylesheet" href="dist/css/hover.css">
  <!-- Color CSS -->
  <link rel="stylesheet" href="dist/css/colors.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="dist/css/animate.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/skin-blue-light.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- DataTables ColReorder-->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/colReorder.dataTables.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Pace style -->
  <link rel="stylesheet" href="plugins/pace/pace.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"> -->
</head>
<body class="hold-transition skin-blue-light sidebar-mini">
<div class="wrapper">

	<?php include('modals/modal.php');?>
	<?php include('tags/header.php');?>

	<?php include('tags/sidebar.php');?>


	  <!-- Content Wrapper. Contains page content -->
	  <div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
		  <h1>
			 <span class="fa fa-sliders fa-fw"></span> DAT Settings
			<small></small>
		  </h1>
		  <ol class="breadcrumb">
			<li><a href="/tabrilya/"><i class="fa fa-gears"></i> Settings</a></li>
			<li class="active">DAT Settings</li>
		  </ol>
		</section>
		<!-- /.content -->
		    <!-- Main content -->
			
		<section class="content animated fadeIn">
		
		<div class="row">
			<div class="col-sm-6">
					 <div class="box">
					 
							<!-- BOX Header -->
							<div class="box-header with-border">
							  <h2 class="box-title"><span class="fa fa-list fa-fw"></span> Number of item per DAT</h2>
							</div>	
							
						<div class="box-body">
						
							<div class="col-md-12">	 
								<div class="pull-right">
								  <button class="btn btn-app bt-flat bg-navy white-text" id="edit-dat-btn" data-toggle="modal" data-target="#modal-confirm-dat">
									<i class="fa fa-pencil"></i> Edit DAT
								  </button>
								 </div>
							</div>
						
							<!-- DAT NUMBER OF ITEM FORM -->
							<form id="dat-form" method="POST" action="functions/edit-dat-item.php" autocomplete="off">
							<?php
							$dat_query = mysqli_query($conn,"SELECT * FROM dat ORDER BY dat_id");
							while($dat_row = mysqli_fetch_array($dat_query)){
								echo "
								   <div class='form-group col-sm-6'>
									  <label>".$dat_row['dat_name']."</label>
									  <input type='number' min='0' value='".$dat_row['dat_items']."' class='form-control' name='dat_".$dat_row['dat_id']."' required disabled>
								   </div>
								";			
							}
							?>
								
													
							
						</div>
						
						  <div class="box-footer edit-submit-btn" style="display: none;">
							<button type="submit" class="pull-right col-sm-4 btn btn-flat bg-olive">Submit</button>
						  </div>
						</form>
						
					 </div>
			</div>
			
			<!-- REQUIRED DAT FOR PER COURSE DIV -->
			<div class="col-sm-6">
					 <div class="box">
					 
							<!-- BOX Header -->
							<div class="box-header with-border">
							  <h2 class="box-title"><span class="fa fa-sitemap fa-fw"></span> Required DAT per Course</h2>
							</div>	
							
						<div class="box-body">
						
							<div class="col-md-12">	 
								<div class="pull-right">
								  <button class="btn btn-app bt-flat bg-navy white-text" onclick="setVal()">
									<i class="fa fa-pencil"></i> Edit DAT
								  </button>
								 </div>
							</div>
							<div class="col-md-12">
	
								<?php
								$query_course = "SELECT * from course";
								$result_course = mysqli_query($conn,$query_course);
									while($row_course = mysqli_fetch_assoc($result_course)){
									echo "
									<div id='course_dat_div_".$row_course['course_id']."' class='row'>
									<h3>".$row_course['course_name']."</h3>";
									$q_req = "SELECT * from course_requirement WHERE course_id = '".$row_course['course_id']."' ORDER BY dat_id";
									$r_req = mysqli_query($conn,$q_req);
										while($row_req = mysqli_fetch_assoc($r_req)){
										$dat = mysqli_fetch_assoc(mysqli_query($conn,"SELECT dat_name from dat WHERE dat_id = '".$row_req['dat_id']."'"));
										echo "
										   <div class='form-group col-sm-6'>
											  <label>".$dat['dat_name']."</label>
											  <input type='number' min='0' value='".$row_req['score']."' class='form-control' name='dat_".$row_req['dat_id']."' step='0.01' required>
										   </div>
										";
										}
									echo "</div>";
								}

								?>							
							</div>
						</div>
						
						  <div class="box-footer edit-submit-btn" style="display: none;">
							<button type="submit" class="pull-right col-sm-4 btn btn-flat bg-olive">Submit</button>
						  </div>
						</form>
						
					 </div>
			</div>
			
		</div>
		 
		</section>
		<!-- /.content -->
		
	  </div>
	  <!-- /.content-wrapper -->

	<?php include('tags/footer.php');?>

	<?php include('tags/control-sidebar.php');?>

 
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- DataTables ColReorder-->
<script src="bower_components/datatables.net-bs/js/dataTables.colReorder.min.js"></script>
<!-- Morris.js charts -->
<script src="bower_components/raphael/raphael.min.js"></script>
<script src="bower_components/morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="bower_components/moment/min/moment.min.js"></script>
<script src="bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- Generate MD5 -->
<script src="dist/js/generateMD5.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- PACE -->
<script src="bower_components/PACE/pace.min.js"></script>
<!--scrolling js-->
<script src="bower_components/nicescroll/jquery.nicescroll.js"></script>
<script src="bower_components/nicescroll/scripts.js"></script>
<!--//scrolling js-->

<script>
$(document).ajaxStart(function() { Pace.restart(); });

    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,
	  format: 'yyyy-mm-dd'
    });

//ENABLE DAT EDIT
function enableDAT(){
	$("#dat-form input[type=number]").each(function(){
	 var input = $(this);
	 input.attr("disabled", false);
	 input.addClass("animated fadeIn");
	});
	$(".edit-submit-btn").css("display","block").addClass("animated fadeIn");
	$("#edit-dat-btn").attr("disabled", true);
}

// DAT CONFIRMATION
$("#dat-confirmation-form").on('submit', function(e) {
 e.preventDefault();
	if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#confirm-password').val())){
		enableDAT(); $("#dat-confirmation-form")[0].reset(); $("#modal-confirm-dat").modal('hide');
	}
	else{
			$('.alert').fadeIn('fast',function(){
				$('.alert span').text("Password Mismatch");		
			});
			$(".alert").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert").css('display:none');
			});
	}
}); 

//AJAX to check date if exist
 function check_date(){
 var values = $('#create-batch-form').serialize();
 if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#create-batch-userpassword').val())){
	$.ajax({
	type: "POST", url: "functions/check_date_exist.php", data: values, dataType: 'JSON', cache: false,
	success: function(response)
	{ 
		if(response.status == 'fail'){
				$('.check-date-alert').fadeIn('fast',function(){
					$('.check-date-alert span').text(response.message);		
				});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
		}
		else if (response.status == "success") {		
			location.href = response.message;
		}

	}
	});
	}
	else{
			$('.check-date-alert').fadeIn('fast',function(){
				$('.check-date-alert span').text("Password Mismatch");		
			});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
	}
	
}

//iCheck
$(function () {
$('#logoutcheckbox').on('ifChanged', function(event){                
      if(event.type ==="ifChanged"){
			$('#logoutform').submit();
           }                             
      }).iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });

</script>

</body>
</html>