<?php
  $dbhost = '127.0.0.1';
  $dbuser = 'root';
  $dbpass = '';
  $db = 'tabrilya_db';
  $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db);

   if(! $conn ){
      die('Could not connect: ' . mysqli_error());
	  echo 'No Connection Found';
	  exit;
    }
    //echo 'Connected successfully';
	
mysqli_set_charset($conn,"utf8");
//mysqli_close($conn);
?>