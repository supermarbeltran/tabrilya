<?php
include_once("db_connection/connect_db.php");
session_start();
if(!isset($_SESSION['cps_pass'])){
	header('location:login.php');
}
//print_r($_SESSION);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CSPC | CPS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Hover CSS -->
  <link rel="stylesheet" href="dist/css/hover.css">
  <!-- Color CSS -->
  <link rel="stylesheet" href="dist/css/colors.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="dist/css/animate.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/skin-blue-light.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Pace style -->
  <link rel="stylesheet" href="plugins/pace/pace.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"> -->
</head>
<body class="hold-transition skin-blue-light sidebar-mini">
<div class="wrapper">

	<?php include('modals/modal.php');?>
	<?php include('tags/header.php');?>

	<?php include('tags/sidebar.php');?>


	  <!-- Content Wrapper. Contains page content -->
	  <div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
		  <h1>
			 <span class="fa fa-graduation-cap fa-fw"></span> Academic Year
			<small></small>
		  </h1>
		  <ol class="breadcrumb">
			<li><a href="/tabrilya/"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li class="active">Academic Year</li>
		  </ol>
		</section>
		<!-- /.content -->
		    <!-- Main content -->
			
		<section class="content animated fadeIn">
		
		 <div class="box">
		 
				<!-- BOX Header -->
				<div class="box-header with-border">
				  <h2 class="box-title"><span class="fa fa-list fa-fw"></span> List of Department and Course</h2>
				</div>
				
			<div class="box-body">
		 
			  <div class="row">
				<?php
					   $query = "SELECT Year(admission_date) as academic_year,count(*) as admission_count from admission_schedule GROUP BY Year(admission_date) ORDER BY academic_year DESC";
					   $result = mysqli_query($conn,$query); $numColor = 0;
					   while($row = mysqli_fetch_assoc($result)){
					   echo "	<a href='view-admission.php?academic_year=".$row['academic_year']."'>
								<div class='col-md-3 col-sm-6 col-xs-12  hvr-shrink'>
								  <div class='info-box white-text ".getColor($numColor)."'>
									<span class='info-box-icon'><i class='fa fa-files-o'></i></span>

									<div class='info-box-content'>
									  <span class='info-box-text'>A / Y</span>
									  <span class='info-box-number'>".$row['academic_year']." - ".($row['academic_year']+1)."</span>
										  <span class='progress-description'>
											".$row['admission_count']." batch of admission
										  </span>
									</div>
									<!-- /.info-box-content -->
								  </div>
								  <!-- /.info-box -->
								</div>
								</a>";
					   $numColor++; if($numColor == 10) $numColor = 0;
					   }
					   function getColor($num){
						$arrayColor = array("bg-blue","bg-green","bg-yellow","cyan darken-2","pink darken-2","bg-navy","bg-gray","bg-purple","bg-teal","bg-maroon");
						return $arrayColor[$num];
					   }
					   
				?>		  

			   </div>
			   
		   </div>
		 </div>
		   
		</section>
	
	  </div>
	  <!-- /.content-wrapper -->

	<?php include('tags/footer.php');?>

	<?php include('tags/control-sidebar.php');?>

 
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="bower_components/raphael/raphael.min.js"></script>
<script src="bower_components/morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="bower_components/moment/min/moment.min.js"></script>
<script src="bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- Generate MD5 -->
<script src="dist/js/generateMD5.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- PACE -->
<script src="bower_components/PACE/pace.min.js"></script>
<!--scrolling js-->
<script src="bower_components/nicescroll/jquery.nicescroll.js"></script>
<script src="bower_components/nicescroll/scripts.js"></script>
<!--//scrolling js-->

<script>
$(document).ajaxStart(function() { Pace.restart(); });

    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,
	  format: 'yyyy-mm-dd'
    })

//AJAX to check date if exist
 function check_date(){
 var values = $('#create-batch-form').serialize();
 if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#create-batch-userpassword').val())){
	$.ajax({
	type: "POST", url: "functions/check_date_exist.php", data: values, dataType: 'JSON', cache: false,
	success: function(response)
	{ 
		if(response.status == 'fail'){
				$('.check-date-alert').fadeIn('fast',function(){
					$('.check-date-alert span').text(response.message);		
				});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
		}
		else if (response.status == "success") {		
			location.href = response.message;
		}

	}
	});
	}
	else{
			$('.check-date-alert').fadeIn('fast',function(){
				$('.check-date-alert span').text("Password Mismatch");		
			});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
	}
	
}

//iCheck
$(function () {
$('#logoutcheckbox').on('ifChanged', function(event){                
      if(event.type ==="ifChanged"){
			$('#logoutform').submit();
           }                             
      }).iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>

</body>
</html>