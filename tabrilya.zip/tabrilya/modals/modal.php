       <!-- create batch modal -->
		<div class="modal fade" id="modal-create-batch">
          <div class="modal-dialog modal-sm" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-calendar fa-fw"></span>Date of Admission</h5>
              </div>
              <div class="modal-body">
			  
			  <form id="create-batch-form">
				  <!-- Date -->
				  <div class="form-group">
					<label>Date:</label>

					<div class="input-group date">
					  <div class="input-group-addon">
						<i class="fa fa-calendar"></i>
					  </div>
					  <input type="text" class="form-control pull-right datepicker" name="create-batch-date" required>
					</div>
					<!-- /.input group -->
				  </div>
				  <!-- /.form group -->
				  
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					<div class="input-group">
					  <div class="input-group-addon">
						<i class="fa fa-key"></i>
					  </div>
					  <input type="password" class="form-control" name="create-batch-userpassword" id="create-batch-userpassword" placeholder="Password">
					</div>
                </div>
				<!-- /.Password -->

			   <div class="check-date-alert alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>	
			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="button" onclick="check_date()" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		

		
       <!-- add applicant modal -->
		<div class="modal fade" id="add-applicant-batch">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-user-plus fa-fw"></span> Add Applicant</h5>
              </div>
              <div class="modal-body col-sm-12">
			  
				<form id="add-applicant-form" autocomplete="off">

					<div class="col-sm-6">
							
								<!-- BOX Header -->
								<div class="box-header">
								  <h3 class="box-title"><span class="fa fa-user fa-fw"></span> Applicants Info</h3>
								</div>	

								<!-- Examinee Number -->
								   <div class="form-group col-sm-6 required">
									  <label>Examinee No.</label>
									  <input type="text" class="form-control" name="applicant-examinee-no" id="" placeholder="Examinee No." required>
								   </div>
								<!-- /.form group -->

								<!-- Course Applied -->
								   <div class="form-group col-sm-6 required">
									  <label>Course Applied</label>
									  <select class="form-control select2" style="width: 100%;" name="applicant-course-applied" id="" placeholder="" required>
										<option selected="selected" value=""></option>
										<?php
										$course_q = "SELECT * from course ORDER BY department_id";
										$course_result = mysqli_query($conn,$course_q);
										while($course_row = mysqli_fetch_assoc($course_result)){
										echo"<option value='".$course_row['course_id']."'>".$course_row['course_shortname']."</option>";
										}
										?>
									  </select>
								   </div>
								<!-- /.form group -->
								
								<!-- First Name -->
								   <div class="form-group col-sm-12 required">
									  <label for="">First Name</label>
									  <input type="text" class="form-control" name="applicant-fname" id="" placeholder="First Name" required>
								   </div>
								<!-- /.form group -->

								<!-- First Name -->
								   <div class="form-group col-sm-12 required">
									  <label>Last Name</label>
									  <input type="text" class="form-control" name="applicant-lname" id="Last Name" placeholder="Last Name" required>
								   </div>
								<!-- /.form group -->

								<!-- First Name -->
								   <div class="form-group col-sm-12">
									  <label >Middle Name/Initial</label>
									  <input type="text" class="form-control" name="applicant-mname" id="" placeholder="Middle Name/Initial" required>
								   </div>
								<!-- /.form group -->

							

								
								<!-- School -->
								   <div class="form-group col-sm-7 required">
									  <label>School</label>
									  <select class="form-control select2" style="width: 100%;" name="applicant-school" id="" placeholder="" required>
										<option selected="selected" value=""></option>
										<?php
										$school_q = "SELECT * from school ORDER BY school_id";
										$school_result = mysqli_query($conn,$school_q);
										while($school_row = mysqli_fetch_assoc($school_result)){
										echo"<option value='".$school_row['school_id']."'>".$school_row['school_name']."</option>";
										}
										?>
									  </select>								  

								  </div>
								<!-- /.form group -->
								
								  <div class="form-group col-sm-5">
										<label>Gender </label>
										<div>
											<label>
											  <input type="radio" name="applicant-gender" value="male" id="gender_1" class="minimal" checked required>
											  Male
											</label>
											<label>
											  <input type="radio" name="applicant-gender" value="female" id="gender_2" class="minimal" required>
											  Female
											</label>
										</div>
								  </div>

					</div>

					<div class="col-sm-6 well">

								<!-- BOX Header -->
								<div class="box-header">
								  <h3 class="box-title"><span class="fa fa-calculator fa-fw"></span> Scores</h3>
								</div>
								<?php
								
								$q = "SELECT * from dat ORDER BY dat_id";
								$r = mysqli_query($conn,$q);
								while($dat = mysqli_fetch_assoc($r)){
								echo "
									
										<div class='form-group col-sm-6 text-center'>
										  <input type='text' class='knob' name='applicant-dat_".$dat['dat_id']."' value='0' data-min='0' data-max='".$dat['dat_items']."' data-width='90' data-angleArc='200' data-angleOffset='-100' data-height='50' data-fgColor='#00a65a' required>
										  <div class='knob-label'><b>".$dat['dat_name']."</b></div>
										</div>									   
								";
								}								

								?>	

				
					</div>
			<div class="col-sm-12">
			   <div class="success-add-applicant-alert alert alert-success alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-check"></i> Success!</h4> <span></span>
			   </div>	
			</div>
			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit"  class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		
		
       <!-- edit applicant modal -->
		<div class="modal fade" id="edit-applicant-batch">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-user-plus fa-fw"></span> Edit Applicant's Info</h5>
              </div>
			  <form id="edit-applicant-form" autocomplete="off">
              <div class="modal-body col-sm-12">
			  
				
			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit"  class="btn btn-sm teal white-text btn-flat">Update</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		

       <!-- add department modal -->
		<div class="modal fade" id="modal-add-department">
          <div class="modal-dialog" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-institution fa-fw"></span>Add Department</h5>
              </div>
              <div class="modal-body">
			  
			  <form id="add-department-form" action="functions/add-department.php" method="POST" autocomplete="off">
			  
				<!-- Department Name -->
					<div class="form-group">
						 <label >Department</label>
							<input type="text" class="form-control" name="department-name" id="" placeholder="Complete Name e.g. College of . ." required>
					</div>
				<!-- /.form group -->
				
				<!-- Department ShortName -->
					<div class="form-group">
						 <label >Department Acronym</label>
							<input type="text" class="form-control" name="department-shortname" id="" placeholder="Acronym" required>
					</div>
				<!-- /.form group -->
				  
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					  <input type="password" class="form-control" name="user-password" id="user-password" placeholder="Password" required>
                </div>
				<!-- /.Password -->

			   <div class="department-alert alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>	
			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		
       <!-- edit department modal -->
		<div class="modal fade" id="modal-edit-department">
          <div class="modal-dialog" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-institution fa-fw"></span>Update Department</h5>
              </div>
			  <form id="edit-department-form" autocomplete="off">
              <div class="modal-body">
			  
			  
			  
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		
		
		
       <!-- add course modal -->
		<div class="modal fade" id="modal-add-course">
          <div class="modal-dialog" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-graduation-cap fa-fw"></span>Add Course</h5>
              </div>
              <div class="modal-body">
			  
			  <form id="add-course-form" autocomplete="off">

			<!-- Course Applied -->
				<div class="form-group">
					<label>Course Department</label>
					<select class="form-control select2" style="width: 100%;" name="course-department-id" id="" placeholder="" required>
						<option selected="selected" value=""></option>
						<?php
						$department_q = "SELECT * from department ORDER BY department_id";
						$department_result = mysqli_query($conn,$department_q);
						while($department_row = mysqli_fetch_assoc($department_result)){
						echo"<option value='".$department_row['department_id']."'>".$department_row['department_name']."</option>";
						}
						?>
					</select>
				</div>
			<!-- /.form group -->
								
				<!-- Course Name -->
					<div class="form-group">
						 <label >Course</label>
							<input type="text" class="form-control" name="course-name" id="" placeholder="Complete Name e.g. (Bachelor of Science in Computer Science)" required>
					</div>
				<!-- /.form group -->
				
				<!-- Course ShortName -->
					<div class="form-group">
						 <label >Course Acronym</label>
							<input type="text" class="form-control" name="course-shortname" id="" placeholder="Acronym" required>
					</div>
				<!-- /.form group -->
				  
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					  <input type="password" class="form-control" name="user-password" id="course-user-password" placeholder="Password" required>
                </div>
				<!-- /.Password -->

			   <div class="course-alert alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>
			   
			   <div class="course-success-alert alert alert-success alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-check"></i> Successful</h4> <span></span>
			   </div>	
			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		
		
       <!-- edit course modal -->
		<div class="modal fade" id="modal-edit-course">
          <div class="modal-dialog" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-graduation-cap fa-fw"></span>Add Course</h5>
              </div>
			  <form id="edit-course-form" autocomplete="off">
              <div class="modal-body">
			  
			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		
       <!-- add school modal -->
		<div class="modal fade" id="modal-add-school">
          <div class="modal-dialog" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-institution fa-fw"></span>Add School</h5>
              </div>
              <div class="modal-body">
			  
			  <form id="add-school-form" autocomplete="off">
								
				<!-- School Name -->
					<div class="form-group">
						 <label >School</label>
							<input type="text" class="form-control" name="school-name" id="" placeholder="Complete Name" required>
					</div>
				<!-- /.form group -->
				
				<!-- School ShortName -->
					<div class="form-group">
						 <label >School Acronym</label>
							<input type="text" class="form-control" name="school-shortname" id="" placeholder="Acronym" required>
					</div>
				<!-- /.form group -->
				  
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					  <input type="password" class="form-control" name="user-password" id="school-user-password" placeholder="Password" required>
                </div>
				<!-- /.Password -->

			   <div class="school-alert alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>
			   
			   <div class="school-success-alert alert alert-success alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-check"></i> Successful</h4> <span></span>
			   </div>	
			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		
       <!-- add school modal -->
		<div class="modal fade" id="modal-edit-school">
          <div class="modal-dialog" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-institution fa-fw"></span>Edit School</h5>
              </div>
			  <form id="edit-school-form" autocomplete="off">
              <div class="modal-body">

			
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
		
		
       <!-- confirmation to edit DAT NUMBER OF ITEMS modal -->
		<div class="modal fade" id="modal-confirm-dat">
          <div class="modal-dialog modal-sm" style="top: 10%;">
            <div class="modal-content">
              <div class="modal-header dark-blue white-text">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h5 class="modal-title"><span class="fa fa-check-square-o fa-fw"></span>Confirmation</h5>
              </div>
			  <form id="dat-confirmation-form" autocomplete="off">
              <div class="modal-body">

				<p>Altering this data may cause some changes to the system</p>
				<!-- Password -->
                <div class="form-group">
					<label>Password:</label>
					  <input type="password" class="form-control" name="user-password" id="confirm-password" placeholder="Password Confirmation" required>
                </div>
				<!-- /.Password -->

			   <div class="alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Failed!</h4> <span></span>
			   </div>	
			   
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm teal white-text btn-flat">Submit</button>
              </div>
			 
			 </form>
			  
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->