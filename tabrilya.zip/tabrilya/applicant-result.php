<?php
include_once("db_connection/connect_db.php");
require_once('class/ahp.php');
session_start();
if(!isset($_SESSION['cps_pass'])){
	header('location:login.php');
}
if($_GET){
	$query = "SELECT * from admission_schedule WHERE admission_schedule_id = '".$_GET['admission_schedule_id']."'";
	$row = mysqli_fetch_assoc(mysqli_query($conn,$query));

	$query_applicant = "SELECT *,concat(applicant_fname,' ',applicant_lname) as applicant_name from applicant_info WHERE applicant_id = '".$_GET['applicant_id']."'";
	$row_applicant = mysqli_fetch_assoc(mysqli_query($conn,$query_applicant));
	
	$query_applicant_school = "SELECT * from school WHERE school_id = '".$row_applicant['school_id']."'";
	$row_applicant_school = mysqli_fetch_assoc(mysqli_query($conn,$query_applicant_school));

	$query_applicant_course = "SELECT * from course WHERE course_id = '".$row_applicant['course_id']."'";
	$row_applicant_course = mysqli_fetch_assoc(mysqli_query($conn,$query_applicant_course));
	
	if(!$row || !$row_applicant) header('location: /tabrilya/');
}
else header('location: /tabrilya/');
?>
<?php
	//AHP CLASS
$criteria_level1 = array ("IMPORTANCE");
$alternativeid_level1 = array();
$alternative_level1 = array();
$temp = array();
$query_dat = mysqli_query($conn,"SELECT * from dat ORDER BY dat_id");
while($row_dat = mysqli_fetch_assoc($query_dat)){
	array_push($alternativeid_level1,$row_dat['dat_name']);
	
	$query_applicant_score = "SELECT score from scores WHERE applicant_id = '".$row_applicant['applicant_id']."' AND dat_id = '".$row_dat['dat_id']."'";
	$row_applicant_score = mysqli_fetch_assoc(mysqli_query($conn,$query_applicant_score));
	$temp[] = ($row_applicant_score['score']/$row_dat['dat_items'])*100;
}
array_push($alternative_level1,$temp);

$ahp_level1 = new AHP();
$ahp_level1->SetCriteria($criteria_level1);
$ahp_level1->SetAlternativeID($alternativeid_level1);
$norm = $ahp_level1->NormalizeAlternative($alternative_level1);
$pw_result_level1 = $ahp_level1->PairWise($norm);
$pw_result_norm_level1 = $ahp_level1->NormalizePairwise($pw_result_level1);
$aggregates_level1 = $ahp_level1->AggregatePairwise($pw_result_norm_level1);
$ahp_rank_level1 = $ahp_level1->RankAggregate($aggregates_level1,-1);


$criteria = array();
$alternativeid = array();
$alternative = array();
$query_course = mysqli_query($conn,"SELECT * from course ORDER BY course_id");
while($row_course = mysqli_fetch_assoc($query_course)){
array_push($alternativeid,$row_course['course_shortname']);
}
$query_dat = mysqli_query($conn,"SELECT * from dat ORDER BY dat_id");
while($row_dat = mysqli_fetch_assoc($query_dat)){
	array_push($criteria,$row_dat['dat_name']);
	$temp = array();
	$query_course_requirement = mysqli_query($conn,"SELECT score from course_requirement WHERE dat_id = '".$row_dat['dat_id']."' ORDER BY course_id");
	while($query_course_requirement_row = mysqli_fetch_assoc($query_course_requirement)){
		$temp[] = $query_course_requirement_row['score'];
	}
	array_push($alternative,$temp);
}
$ahp = new AHP();
$ahp->SetCriteria($criteria);
$ahp->SetAlternativeID($alternativeid);
$norm_euclid = $ahp->NormalizeAlternative_Euclidean_Distance($alternative,$ahp_rank_level1);
$norm = $ahp->NormalizeAlternative_Euclid($norm_euclid);
$pw_result = $ahp->PairWise($norm);
$pw_result_norm = $ahp->NormalizePairwise($pw_result);
$aggregates = $ahp->AggregatePairwise_respectToLevel1($pw_result_norm,$ahp_rank_level1);
$ahp_rank = $ahp->RankAggregateLevel1($aggregates,-1);

$arrayColorDat = array("#e91e63","#4527a0","#0277bd","#2e7d32","#f9a825","#d84315","#ad1457","#283593","#00838f");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CSPC | CPS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Hover CSS -->
  <link rel="stylesheet" href="dist/css/hover.css">
  <!-- Color CSS -->
  <link rel="stylesheet" href="dist/css/colors.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="dist/css/animate.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/skin-blue-light.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- DataTables ColReorder-->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/colReorder.dataTables.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Pace style -->
  <link rel="stylesheet" href="plugins/pace/pace.min.css">
<!-- Chart.Js -->
<script src="bower_components/chart.js/Chart.bundle.js"></script>
<script src="bower_components/chart.js/utils.js"></script>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"> -->

</head>
<body class="hold-transition skin-blue-light sidebar-mini">
<div class="wrapper">

	<?php include('modals/modal.php');?>
	<?php include('tags/header.php');?>

	<?php include('tags/sidebar.php');?>


	  <!-- Content Wrapper. Contains page content -->
	  <div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
		  <h1>
			 <span class="fa fa-line-chart fa-fw"></span> Applicant Result
			<small></small>
		  </h1>
		  <ol class="breadcrumb">
			<li><a href="/tabrilya/"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li><a href="/tabrilya/view-academic-year.php">Academic Year</a></li>
			<li><a href="/tabrilya/view-admission.php?academic_year=<?php echo date_format(date_create($row['admission_date']),"Y");?>">Admission Schedules</a></li>
			<li><a href="/tabrilya/view-applicant-list.php?admission_schedule_id=<?php echo $_GET['admission_schedule_id'];?>" >List of Applicants</a></li>
			<li class="active">Applicant Result</li>
		  </ol>
		</section>
		<!-- /.content -->
		
		    <!-- Main content -->
		<section class="content animated fadeIn">
		
		 <div class="box">
		 
			<div class="box-body">
			
				<!-- BOX Header -->
				<div class="box-header with-border">
				</div>	
					<div class="col-md-5">
						<!-- Widget: user widget style 1 -->
						  <div class="box box-widget widget-user-2">
							<!-- Add the bg color to the header using any of the bg-* classes -->
							<div class="widget-user-header bg-yellow">
							  <div class="widget-user-image">
								<img class="img-circle" src="dist/img/<?php echo $row_applicant['applicant_gender'];?>.png">
							  </div>
							  <!-- /.widget-user-image -->
							  <h3 class="widget-user-username"><?php echo $row_applicant['applicant_name'];?></h3>
							  <h5 class="widget-user-desc"><span class="fa fa-institution fa-fw"></span> <?php echo $row_applicant_school['school_name'];?></h5>
							</div>
							<div class="box-footer no-padding">
							  <ul class="nav nav-stacked">
								<li><a><span class="fa fa-info fa-fw"></span>Examinee No: <b><?php echo $row_applicant['applicant_exam_no'];?></b></a></li>
								<li><a><span class="fa fa-graduation-cap fa-fw"></span> Course Applied: <b><?php echo $row_applicant_course['course_shortname'];?></b></a></li>
							  </ul>
							</div>
						  </div>
						  <!-- /.widget-user -->

						<div id="canvas-holder" style="width:100%;">
							<canvas id="mypieChart" />
						</div>
						
						<!-- TABLE RANKING DAT -->
						  <table id="" class="table table-bordered table-striped table-hover text-center">
							<thead>			
							<tr class="teal teal darken-3 white-text">
							  <th>DAT</th>
							  <th>%</th>
							  <th>RANK</th>
							</tr>
							</thead>
								<tbody>
								<?php
									for($i = 0; $i < count($ahp_rank_level1); $i++){
									echo "<tr>
											<td style='color: ".$arrayColorDat[$i].";'><b>".$ahp_rank_level1[$i][0]."</b></td>
											<td>".number_format(($ahp_rank_level1[$i][1]*100),'2','.','').'%'."</td>
											<td>".$ahp_rank_level1[$i][2]."</td>
										  </tr>";									
									}
								?>
								</tbody>
						  </table>
						  <!-- /.Table -->	
						
					</div>

					<div class="col-md-7">
						<h3>Percentile per DAT</h3>
						<?php
						for($i = 0; $i < count($alternative_level1[0]); $i++){
						echo "
							<div class='form-group col-sm-4 ".($i==6?'col-sm-offset-4':'')." text-center'>
								<input type='text' class='knob' value='".number_format($alternative_level1[0][$i],1,'.','')."' data-min='0' data-max='100' data-skin='tron' data-thickness='0.2' data-width='120' data-height='120' data-step='0.01' data-fgColor='".$arrayColorDat[$i]."' data-readonly='true'>
								<div class='knob-label'><b>".$alternativeid_level1[$i]."</b></div>
							</div>
							";
						}
						?>
						<div id="canvas-holder" style="width:100%;">
							<canvas id="myHorizontalBarChart" />
						</div>
					
					</div>
					
				<div class="col-md-12">
						<div id="canvas-holder" style="width:100%;">
							<canvas id="mylineChart" />
						</div>
				</div>
			
	
		    </div>
			
		 </div>
		   
		</section>
	
	  </div>
	  <!-- /.content-wrapper -->

	<?php include('tags/footer.php');?>

	<?php include('tags/control-sidebar.php');?>

 
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- DataTables ColReorder-->
<script src="bower_components/datatables.net-bs/js/dataTables.colReorder.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="bower_components/moment/min/moment.min.js"></script>
<script src="bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- Generate MD5 -->
<script src="dist/js/generateMD5.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- PACE -->
<script src="bower_components/PACE/pace.min.js"></script>
<!--scrolling js-->
<script src="bower_components/nicescroll/jquery.nicescroll.js"></script>
<script src="bower_components/nicescroll/scripts.js"></script>
<!--//scrolling js-->
<?php
$applicant_dat_label = array();
$applicant_dat_final_score = array();
	for($i = 0; $i < count($ahp_rank_level1); $i++){
		$applicant_dat_label[] = $ahp_rank_level1[$i][0].' - '.number_format(($ahp_rank_level1[$i][1]*100),'2','.','').'%';
		$applicant_dat_final_score[] = number_format(($ahp_rank_level1[$i][1]*100),'2','.','');
	}
$course_dat = array();
for($j = 0; $j < count($alternative[0]); $j++){
	$temp = array();
	for($i = 0; $i < count($alternative); $i++){
		$temp[] = number_format($alternative[$i][$j],'2','.','');
	}
	$course_dat[] = $temp;
}
$course_dat[] = $applicant_dat_final_score;

$course_dat_final_score = array();
	for($i = 0; $i < count($ahp_rank); $i++){
		$course_dat_final_score[] = number_format(($ahp_rank[$i][1]*100),'2','.','');
	}
	
$temp_alternativeid = $alternativeid;
$temp_alternativeid[] = "My DAT";
?>
<script>
var ctx = document.getElementById("mylineChart").getContext("2d");
var dataSetArray = [];
var colorNames = Object.keys(window.chartColors);
var courses = <?php echo json_encode($temp_alternativeid);?>;
var dat_label = <?php echo json_encode($criteria);?>;
var course_dat = <?php echo json_encode($course_dat);?>;
for(var index = 0; index < <?php echo json_encode(count($temp_alternativeid));?>; index++){
var colorName = colorNames[index % colorNames.length];
var newColor = window.chartColors[colorName];
var newDataset = {
                label: courses[index],
                backgroundColor: newColor,
                borderColor: newColor,
                data: course_dat[index],
                fill: false
}
dataSetArray.push(newDataset);
}

	var mylineChart = new Chart(ctx, {
        type: 'line',
        data: {
			labels: dat_label,
			datasets: dataSetArray        
        },
        options: {
			        title: {
					display: true,
					text: 'Courses DAT line pattern',
					fontFamily: 'Arial',
					fontColor: "Black",
					fontSize: 15
				},
				    legend: {
					display: true,
					position: 'right',
					labels: {
						fontColor: 'rgb(54, 162, 235)'
					}
				},
					scales: {
						xAxes: [{
							display: true,
							scaleLabel: {
								display: true,
								fontSize: 20
							}
						}],
						yAxes: [{
							display: true,
							scaleLabel: {
								display: true,
								fontSize: 20,
								labelString: 'Value'
							},
							  ticks: {
								beginAtZero:true,
								mirror:false,
								suggestedMin: 0,
							  }
						}]
                },
				    hover: {
                    mode: 'nearest',
                    intersect: true
                },
				    tooltips: {
                    mode: 'index',
                    intersect: false,
                },
				    animation: {
                    duration: 2000,
					easing: 'easeInExpo'
                },
            responsive: true
        }
    });
	

dataSetArray = [];
var colorNames = Object.keys(window.chartColors);
var courses = <?php echo json_encode($alternativeid);?>;
var course_final_score = <?php echo json_encode($course_dat_final_score);?>;
for(var index = 0; index < <?php echo json_encode(count($alternativeid));?>; index++){
var colorName = colorNames[index % colorNames.length];
var newColor = window.chartColors[colorName];
var newDataset = {
                label: courses[index],
				backgroundColor: newColor,
                borderColor: newColor,
				pointBackgroundColor: newColor,
                data: [course_final_score[index]]
}
dataSetArray.push(newDataset);
}

    var myradarChart = new Chart(document.getElementById("myHorizontalBarChart").getContext("2d"), {
        type: 'bar',
        data: {
			labels: [""],
			datasets: dataSetArray        
        },
        options: {
			        title: {
					display: true,
					text: 'Course DAT',
					fontFamily: 'Arial',
					fontColor: "Black",
					fontSize: 14
				},
				    legend: {
					display: true,
					position: 'top',
					labels: {
						fontColor: 'rgb(75, 192, 192)',
						fontSize: 14
					}
				},
				    hover: {
                    mode: 'nearest',
                    intersect: true
                },
				    tooltips: {
                    mode: 'index',
					backgroundColor: 'rgb(47,30,22)',
                    intersect: false,
                },
				    animation: {
                    duration: 2000,
					easing: 'easeInExpo'
                },
				scales: {
					yAxes: [{
					  id: 'y-axis-0',
					  gridLines: {
						display: true,
						lineWidth: 0,
						color: "rgba(0,0,0,0.30)"
					  },
					  ticks: {
						beginAtZero:true,
						mirror:false,
						suggestedMin: 0,
					  },
					  afterBuildTicks: function(chart) {
					  }
					}],
				},
            responsive: true
        }
    });
	
	
var dataSetArray = [];
var colorNames = <?php echo json_encode($arrayColorDat);?>;
var applicant_dat_label = <?php echo json_encode($applicant_dat_label);?>;
var applicant_dat_final_score = <?php echo json_encode($applicant_dat_final_score);?>;
for(var index = 0; index < 7; index++){
var colorName = colorNames[index % colorNames.length];
dataSetArray.push(colorName);
}
    var mypieChart = new Chart(document.getElementById("mypieChart").getContext("2d"), {
        type: 'pie',
        data: {
            datasets: [{
                data: applicant_dat_final_score,
                backgroundColor: dataSetArray,
                label: 'Dataset 1'
            }],
            labels: applicant_dat_label
        },
        options: {
				title: {
					display: true,
					text: "Applicant's DAT Ranking",
					fontFamily: 'Arial',
					fontSize: 18
				},
				legend: {
					display: true,
					position: 'bottom',
					labels: {
						fontColor: 'rgb(00, 00, 0)',
						fontSize: 14
					}
				},
            responsive: true,
			easing: 'easeOutBounce'
        }
    });
</script>
<script>
$(document).ajaxStart(function() { Pace.restart(); });

    //Initialize Select2 Elements
    $('.select2').select2();
	
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,
	  format: 'yyyy-mm-dd'
    })

 /* jQueryKnob */
 $(function () {
    /* jQueryKnob */

    $(".knob").knob({
      /*change : function (value) {
       //console.log("change : " + value);
       },
       release : function (value) {
       console.log("release : " + value);
       },
       cancel : function () {
       console.log("cancel : " + this.value);
       },*/
	  'format' : function (value) {
		 return value + '%';
	  },
      draw: function () {

        // "tron" case
        if (this.$.data('skin') == 'tron') {

          var a = this.angle(this.cv)  // Angle
              , sa = this.startAngle          // Previous start angle
              , sat = this.startAngle         // Start angle
              , ea                            // Previous end angle
              , eat = sat + a                 // End angle
              , r = true;

          this.g.lineWidth = this.lineWidth;

          this.o.cursor
          && (sat = eat - 0.3)
          && (eat = eat + 0.3);

          if (this.o.displayPrevious) {
            ea = this.startAngle + this.angle(this.value);
            this.o.cursor
            && (sa = ea - 0.3)
            && (ea = ea + 0.3);
            this.g.beginPath();
            this.g.strokeStyle = this.previousColor;
            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sa, ea, false);
            this.g.stroke();
          }

          this.g.beginPath();
          this.g.strokeStyle = r ? this.o.fgColor : this.fgColor;
          this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sat, eat, false);
          this.g.stroke();

          this.g.lineWidth = 2;
          this.g.beginPath();
          this.g.strokeStyle = this.o.fgColor;
          this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
          this.g.stroke();

          return false;
        }
      }
    });
    /* END JQUERY KNOB */
 });

//iCheck
$(function () {
$('#logoutcheckbox').on('ifChanged', function(event){                
      if(event.type ==="ifChanged"){
			$('#logoutform').submit();
           }                             
      }).iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });

</script>

</body>
</html>