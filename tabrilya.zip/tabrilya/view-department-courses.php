<?php
include_once("db_connection/connect_db.php");
session_start();
if(!isset($_SESSION['cps_pass'])){
	header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CSPC | CPS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Hover CSS -->
  <link rel="stylesheet" href="dist/css/hover.css">
  <!-- Color CSS -->
  <link rel="stylesheet" href="dist/css/colors.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="dist/css/animate.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/skin-blue-light.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- DataTables ColReorder-->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/colReorder.dataTables.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Pace style -->
  <link rel="stylesheet" href="plugins/pace/pace.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"> -->
</head>
<body class="hold-transition skin-blue-light sidebar-mini">
<div class="wrapper">

	<?php include('modals/modal.php');?>
	<?php include('tags/header.php');?>

	<?php include('tags/sidebar.php');?>


	  <!-- Content Wrapper. Contains page content -->
	  <div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
		  <h1>
			 <span class="fa fa-institution fa-fw"></span> Department and Courses
			<small></small>
		  </h1>
		  <ol class="breadcrumb">
			<li><a href="/tabrilya/"><i class="fa fa-gears"></i> Settings</a></li>
			<li class="active">Department and Courses</li>
		  </ol>
		</section>
		<!-- /.content -->
		    <!-- Main content -->
			
		<section class="content animated fadeIn">
		
		<!-- DIV ROW -->
		<div class="row">
		
		<!-- DIV LEFT -->
		<div class="col-sm-6">
		
		 <div class="box">
		 
				<!-- BOX Header -->
				<div class="box-header with-border">
				  <h2 class="box-title"><span class="fa fa-list fa-fw"></span> List of Department and Course</h2>
				</div>	
				
			<div class="box-body">
	
						<div class="col-md-12">
							<div class="pull-right">
							  <span class="btn btn-app bt-flat bg-navy white-text" data-toggle="modal" data-target="#modal-add-department">
								<i class="fa fa-institution"></i> Add Department
							  </span>
							 </div>
						</div>

						<!-- Table -->
						  <table id="department-data-table" class="table table-bordered table-striped table-hover text-center">
							<thead>			
							<tr class="teal teal darken-3 white-text">
							  <th>No.</th>
							  <th>Department Name</th>
							  <th>Action</th>
							</tr>
							</thead>
								<tbody>
								<?php
											$department_query = mysqli_query($conn,"SELECT * FROM department" );
											$rowNum = 0;
											while($department_row = mysqli_fetch_array($department_query)){
												$rowNum++;
												echo "<tr>
												<td>".$rowNum.".</td>
												<td>".$department_row['department_name']."<b> (".$department_row['department_shortname'].")</b></td>
												<td>
												<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_department(".$department_row['department_id'].")'><i class='fa fa-edit fa-fw'></i></span>
												</td>";
												echo "</tr>";
											}

								?>
								</tbody>
						  </table>
						  <!-- /.Table -->
	
		    </div>
			
		 </div>
		 
	
		 <div class="box">
		 
				<!-- BOX Header -->
				<div class="box-header with-border">
				  <h2 class="box-title"><span class="fa fa-list fa-fw"></span> List of Applicants School</h2>
				</div>	
				
			<div class="box-body">
	
						<div class="col-md-12">
							<div class="pull-right">
							  <span class="btn btn-app bt-flat bg-navy white-text" data-toggle="modal" data-target="#modal-add-school">
								<i class="fa fa-institution"></i> Add School
							  </span>
							 </div>
							 
						</div>
				 
				<!-- School TABLE -->
					
						<!-- Table -->
						  <table id="school-data-table" class="table table-bordered table-striped table-hover text-center">
							<thead>			
							<tr class="teal teal darken-3 white-text">
							  <th>No.</th>
							  <th>School Name</th>
							  <th>Created by</th>
							  <th>Action</th>
							</tr>
							</thead>
								<tbody>
								<?php
											$school_query = mysqli_query($conn,"SELECT * FROM school");
											$rowNum = 0;
											while($school_row = mysqli_fetch_array($school_query)){
											$account_row = mysqli_fetch_array(mysqli_query($conn,"SELECT user_username FROM accounts WHERE user_id=".$school_row['created_by']));
											$rowNum++;
												echo "<tr>
												<td>".$rowNum.".</td>
												<td>".$school_row['school_name']." <b>(".$school_row['school_shortname'].")</b></td>
												<td>".($_SESSION['username']==$account_row['user_username']?"<b>(me)</b> ":"").$account_row['user_username']."</td>
												<td>
												<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_school(".$school_row['school_id'].")'><i class='fa fa-edit fa-fw'></i></span>
												</td>";
												echo "</tr>";
											}

								?>
								</tbody>
						  </table>

				 <!-- /.School TABLE -->				 
				 
		    </div>
			
		 </div>

		 </div>
		 <!-- /.DIV LEFT -->
		 
		 <!-- DIV RIGHT -->
		 <div class="col-sm-6">
		
		 <div class="box">
		 
				<!-- BOX Header -->
				<div class="box-header with-border">
				  <h2 class="box-title"><span class="fa fa-list fa-fw"></span> List of Courses</h2>
				</div>	
				
			<div class="box-body">
	
						<div class="col-md-12">	 
							<div class="pull-right">
							  <span class="btn btn-app bt-flat bg-navy white-text" data-toggle="modal" data-target="#modal-add-course">
								<i class="fa fa-graduation-cap"></i> Add Course
							  </span>
							 </div>
						</div>
					
						<!-- Table -->
						  <table id="course-data-table" class="table table-bordered table-striped table-hover text-center">
							<thead>			
							<tr class="teal teal darken-3 white-text">
							  <th>No.</th>
							  <th>Department</th>
							  <th>Course Name</th>
							  <th>Action</th>
							</tr>
							</thead>
								<tbody>
								<?php
											$course_query = mysqli_query($conn,"SELECT * FROM course ORDER BY department_id");
											$rowNum = 0;
											while($course_row = mysqli_fetch_array($course_query)){
											$department_name_row = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM department WHERE department_id=".$course_row['department_id']));
												$rowNum++;
												echo "<tr>
												<td>".$rowNum.".</td>
												<td>".$department_name_row['department_shortname']."</td>
												<td>".$course_row['course_name']."<b> (".$course_row['course_shortname'].")</b></td>
												<td>
												<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_course(".$course_row['course_id'].")'><i class='fa fa-edit fa-fw'></i></span>
												</td>";
												echo "</tr>";
											}

								?>
								</tbody>
						  </table>
						  <!-- /.Table -->	 
				 
		    </div>
			
		 </div>
		
		 </div>
		 <!-- /.DIV RIGHT -->
		 

		 </div>
		 <!-- /.DIV ROW -->
		 
		 
		</section>
		<!-- /.content -->
		
	  </div>
	  <!-- /.content-wrapper -->

	<?php include('tags/footer.php');?>

	<?php include('tags/control-sidebar.php');?>

 
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- DataTables ColReorder-->
<script src="bower_components/datatables.net-bs/js/dataTables.colReorder.min.js"></script>
<!-- Morris.js charts -->
<script src="bower_components/raphael/raphael.min.js"></script>
<script src="bower_components/morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="bower_components/moment/min/moment.min.js"></script>
<script src="bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- Generate MD5 -->
<script src="dist/js/generateMD5.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- PACE -->
<script src="bower_components/PACE/pace.min.js"></script>
<!--scrolling js-->
<script src="bower_components/nicescroll/jquery.nicescroll.js"></script>
<script src="bower_components/nicescroll/scripts.js"></script>
<!--//scrolling js-->

<script>
$(document).ajaxStart(function() { Pace.restart(); });

    //Initialize Select2 Elements
    $('.select2').select2();
	
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,
	  format: 'yyyy-mm-dd'
    })
	
 //department DataTable ini	
	department_DT_ini();
function department_DT_ini(){
	$('#department-data-table').DataTable( {
      'paging'      : false,
	  'paginationType': "full_numbers",
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false,
	  'responsive'	: true,
	  'columnDefs'	: [ {"targets": [2],"orderable": false}],
	  'language'	: {
				   search: "<span class='fa fa-search'></span>",
        searchPlaceholder: "Search Department"
					}
	} 
	);
}

 //course DataTable ini	
 course_DT_ini();
function course_DT_ini(){
	$('#course-data-table').DataTable( {
      'paging'      : false,
	  'paginationType': "full_numbers",
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false,
	  'responsive'	: true,
	  'columnDefs'	: [ {"targets": [1,2,3],"orderable": false}],
	  'language'	: {
					search: "<span class='fa fa-search'></span>",
        searchPlaceholder: "Search Course"
					}
	} 
	);
}

 //school DataTable ini	
school_DT_ini();
function school_DT_ini(){
	$('#school-data-table').DataTable( {
      'paging'      : false,
	  'paginationType': "full",
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false,
	  'responsive'	: true,
	  'columnDefs'	: [ {"targets": [3],"orderable": false}],
	  'language'	: {
				   search: "<span class='fa fa-search'></span>",
        searchPlaceholder: "Search School"
					}
	} 
	);
}


//AJAX to update department table
 function update_department_table(){
 	$.ajax({
	url: "functions/get-department-table-data.php", cache: false,
	success: function(response)
	{
		$('#department-data-table').dataTable().fnDestroy();
		$('#department-data-table').html(response);
		department_DT_ini();
	}
	});
}

//AJAX to update course table
 function update_course_table(){
 	$.ajax({
	url: "functions/get-course-table-data.php", cache: false,
	success: function(response)
	{
		$('#course-data-table').dataTable().fnDestroy();
		$('#course-data-table').html(response);
		course_DT_ini();
	}
	});
}

//AJAX to update school table
 function update_school_table(){
 	$.ajax({
	url: "functions/get-school-table-data.php", cache: false,
	success: function(response)
	{
		$('#school-data-table').dataTable().fnDestroy();
		$('#school-data-table').html(response);
		school_DT_ini();
	}
	});
}

// Add Department
$("#add-department-form").on('submit', function(e) {
 
	if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#user-password').val())){
		$("#add-department-form").submit();
	}
	else{
			e.preventDefault();
			$('.department-alert').fadeIn('fast',function(){
				$('.department-alert span').text("Password Mismatch");		
			});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
	}
}); 

// Add Course
$("#add-course-form").on('submit', function(e) {
 e.preventDefault();
	var values = $('#add-course-form').serialize();
	if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#course-user-password').val())){

			$.ajax({
			type: "POST", url: "functions/add-course.php", data: values, cache: false,
			success: function(response)
			{ 
				$('.course-success-alert').fadeIn('fast',function(){
					$('.course-success-alert span').text("Added Successfully!");		
				});
				$(".course-success-alert").fadeTo(2000, 500).slideUp(500, function(){
					$(".course-success-alert").css('display:none');
				});
				$('#add-course-form')[0].reset();
				update_department_table();
				update_course_table();
			}
			});	
	
	}
	else{
			$('.course-alert').fadeIn('fast',function(){
				$('.course-alert span').text("Password Mismatch");		
			});
			$(".course-alert").fadeTo(2000, 500).slideUp(500, function(){
				$(".course-alert").css('display:none');
			});
	}
}); 

// Add School
$("#add-school-form").on('submit', function(e) {
 e.preventDefault();
	var values = $('#add-school-form').serialize(); values = values+"&created-by="+<?php echo json_encode($_SESSION['user_id']); ?>;
	if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#school-user-password').val())){

			$.ajax({
			type: "POST", url: "functions/add-school.php", data: values, cache: false,
			success: function(response)
			{ 
				$('.school-success-alert').fadeIn('fast',function(){
					$('.school-success-alert span').text("Added Successfully!");		
				});
				$(".school-success-alert").fadeTo(2000, 500).slideUp(500, function(){
					$(".school-success-alert").css('display:none');
				});
				$('#add-school-form')[0].reset();
				update_school_table();
			}
			});	
	
	}
	else{
			$('.school-alert').fadeIn('fast',function(){
				$('.school-alert span').text("Password Mismatch");		
			});
			$(".school-alert").fadeTo(2000, 500).slideUp(500, function(){
				$(".school-alert").css('display:none');
			});
	}
}); 

//AJAX Edit Department
$("#edit-department-form").on('submit', function(e) {
 e.preventDefault();
	var values = $('#edit-department-form').serialize();
	if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#department-user-password').val())){
		
			$.ajax({
			type: "POST", url: "functions/edit-department.php", data: values, cache: false,
			success: function(response)
			{ 
				$('.department-success-alert').fadeIn('fast',function(){
					$('.department-success-alert span').text("Updated Successfully!");		
				});
				$(".department-success-alert").fadeTo(2000, 500).slideUp(500, function(){
					$(".department-success-alert").css('display:none');
				});
				update_department_table();
				update_course_table();
			}
			});
		
	}
	else{
			
			$('.department-alert').fadeIn('fast',function(){
				$('.department-alert span').text("Password Mismatch");		
			});
			$(".department-alert").fadeTo(2000, 500).slideUp(500, function(){
				$(".department-alert").css('display:none');
			});
	}


}); 

//AJAX Edit Course
$("#edit-course-form").on('submit', function(e) {
 e.preventDefault();
	var values = $('#edit-course-form').serialize();
	if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#course-edit-user-password').val())){
		
			$.ajax({
			type: "POST", url: "functions/edit-course.php", data: values, cache: false,
			success: function(response)
			{ 
				$('.course-success-alert').fadeIn('fast',function(){
					$('.course-success-alert span').text("Added Successfully!");		
				});
				$(".course-success-alert").fadeTo(2000, 500).slideUp(500, function(){
					$(".course-success-alert").css('display:none');
				});
				$('#add-course-form')[0].reset();
				update_department_table();
				update_course_table();
			}
			});
		
	}
	else{
			$('.course-alert').fadeIn('fast',function(){
				$('.course-alert span').text("Password Mismatch");		
			});
			$(".course-alert").fadeTo(2000, 500).slideUp(500, function(){
				$(".course-alert").css('display:none');
			});
	}


});

//AJAX Edit School
$("#edit-school-form").on('submit', function(e) {
 e.preventDefault();
	var values = $('#edit-school-form').serialize();
	if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#school-edit-user-password').val())){
		
			$.ajax({
			type: "POST", url: "functions/edit-school.php", data: values, cache: false,
			success: function(response)
			{ 
				$('.school-success-alert').fadeIn('fast',function(){
					$('.school-success-alert span').text("Added Successfully!");		
				});
				$(".school-success-alert").fadeTo(2000, 500).slideUp(500, function(){
					$(".school-success-alert").css('display:none');
				});
				$('#add-school-form')[0].reset();
				update_school_table();
			}
			});
		
	}
	else{
			$('.school-alert').fadeIn('fast',function(){
				$('.school-alert span').text("Password Mismatch");		
			});
			$(".school-alert").fadeTo(2000, 500).slideUp(500, function(){
				$(".school-alert").css('display:none');
			});
	}


});


//AJAX to get department edit Modal
function getEditModal_department(id){
	$.ajax({
	type: "POST", url: "functions/get-department-edit-modal.php", data: "department_id="+id, cache: false,
	success: function(response)
	{ 
		$('#modal-edit-department .modal-body').html(response);
		$('#modal-edit-department').modal();
	}
	});
}

//AJAX to get course edit Modal
function getEditModal_course(id){
	$.ajax({
	type: "POST", url: "functions/get-course-edit-modal.php", data: "course_id="+id, cache: false,
	success: function(response)
	{ 
		$('#modal-edit-course .modal-body').html(response);
		$('#modal-edit-course').modal();
	}
	});
}

//AJAX to get school edit Modal
function getEditModal_school(id){
	$.ajax({
	type: "POST", url: "functions/get-school-edit-modal.php", data: "school_id="+id, cache: false,
	success: function(response)
	{ 
		$('#modal-edit-school .modal-body').html(response);
		$('#modal-edit-school').modal();
	}
	});
}


//AJAX to check date if exist
 function check_date(){
 var values = $('#create-batch-form').serialize();
 if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#create-batch-userpassword').val())){
	$.ajax({
	type: "POST", url: "functions/check_date_exist.php", data: values, dataType: 'JSON', cache: false,
	success: function(response)
	{ 
		if(response.status == 'fail'){
				$('.check-date-alert').fadeIn('fast',function(){
					$('.check-date-alert span').text(response.message);		
				});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
		}
		else if (response.status == "success") {		
			location.href = response.message;
		}

	}
	});
	}
	else{
			$('.check-date-alert').fadeIn('fast',function(){
				$('.check-date-alert span').text("Password Mismatch");		
			});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
	}
	
}

//iCheck
$(function () {
$('#logoutcheckbox').on('ifChanged', function(event){                
      if(event.type ==="ifChanged"){
			$('#logoutform').submit();
           }                             
      }).iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });

</script>

</body>
</html>