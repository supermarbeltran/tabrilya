<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CPS | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Color CSS -->
  <link rel="stylesheet" href="dist/css/colors.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="dist/css/animate.css">
  <!-- Hover CSS -->
  <link rel="stylesheet" href="dist/css/hover.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Pace style -->
  <link rel="stylesheet" href="plugins/pace/pace.min.css">
  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!--<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">-->
</head>
<body class="hold-transition dark-blue">

<div class="container animated fadeIn">

	<div class="col-sm-6 text-center" style="border-right: 1px solid gray; margin-top: 10%;">
		<img class="hvr-float" src="dist/img/cpslogin.png" width="60%" height="60%">
	</div>

	
	
	<div class="col-sm-4 col-sm-offset-1" style="margin-top: 10%;">
	  <div class="login-logo">
		<a href="/tabrilya/"><img src="dist/img/cspclogo.png" width="30%" height="30%" ></a>
	  </div>
	  
	  <!-- /.login-logo -->
	  <div class="login-box-body transparent">
	  
	  <div>
		<h4 class="white-text">Login</h4>
	  </div>
	  
		<form id="loginform" autocomplete="off">
		  <div class="form-group has-feedback">
			<input type="text" class="form-control dark-blue white-text" name="username" placeholder="@Username" pattern="@[A-Za-z0-9]+" title="Username should have '@' prefix" required>
			<span class="fa fa-user form-control-feedback"></span>
		  </div>
		  <div class="form-group has-feedback">
			<input type="password" class="form-control dark-blue white-text" name="password" placeholder="Password" required>
			<span class="fa fa-lock form-control-feedback"></span>
		  </div>
		  
			   <div class="alert alert-danger alert-dismissible" style="display: none;">
				 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <h4><i class="icon fa fa-ban"></i> Alert!</h4> <span></span>
			   </div>	
			   
		  <div class="row">
		  
			<div class="col-xs-4 pull-right">
			  <button type="submit" class="btn teal accent-4 white-text btn-login btn-block">Login</button>
			</div>
			
			<div class="col-xs-4 pull-right">
			  <button type="button" onclick="$('#loginform')[0].reset()" class="btn teal accent-4 white-text btn-login btn-block">Reset</button>
			</div>
			<!-- /.col -->
		  </div>
		</form>

	  </div>
	  <!-- /.login-box-body -->
	</div>
	<!-- /.login-box -->


</div>

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- PACE -->
<script src="bower_components/PACE/pace.min.js"></script>
<script>
$(document).ajaxStart(function() { Pace.restart(); });
//AJAX to LOGIN
$("#loginform").on('submit', function(e) {
 e.preventDefault();
 var values = $('#loginform').serialize();
	$.ajax({
	type: "POST",
	url: "functions/check_user.php",
	data: values,
	dataType: 'JSON',
	cache: false,
	success: function(response)
	{ 
		if(response.status == 'fail'){
				$('.alert').fadeIn('fast',function(){
					$('.alert span').text(response.message);		
				});
				$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
					$(".alert-dismissible").css('display:none');
				});
		}
		else if (response.status == "success") {		
			location.href = response.message;			
		}

	}
	}); 
}); 
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });

</script>
</body>
</html>
