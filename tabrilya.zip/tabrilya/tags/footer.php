  <footer class="main-footer grey lighten-4">
    <div class="pull-right hidden-xs">
      <b>TEAM<a href="">Tabrilya</a></b>
    </div>
    <strong>Copyright &copy; 2017-2018 <a href="">CSPC::CoursePlacementSystem</a>.</strong> All rights
    reserved.
  </footer>