<?php
include_once("db_connection/connect_db.php");
session_start();
if(!isset($_SESSION['cps_pass'])){
	header('location:login.php');
}
if($_GET){
	$query = "SELECT * from admission_schedule where admission_schedule_id = '".$_GET['admission_schedule_id']."'";
	$row = mysqli_fetch_assoc(mysqli_query($conn,$query));
	
	if(!$row) header('location: /tabrilya/');
}
else header('location: /tabrilya/');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CSPC | CPS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Hover CSS -->
  <link rel="stylesheet" href="dist/css/hover.css">
  <!-- Color CSS -->
  <link rel="stylesheet" href="dist/css/colors.css">
  <!-- Animate CSS -->
  <link rel="stylesheet" href="dist/css/animate.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/skin-blue-light.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- DataTables ColReorder-->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/colReorder.dataTables.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  <!-- Pace style -->
  <link rel="stylesheet" href="plugins/pace/pace.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic"> -->
</head>
<body class="hold-transition skin-blue-light sidebar-mini">
<div class="wrapper">

	<?php include('modals/modal.php');?>
	<?php include('tags/header.php');?>

	<?php include('tags/sidebar.php');?>


	  <!-- Content Wrapper. Contains page content -->
	  <div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
		  <h1>
			 <span class="fa fa-users fa-fw"></span> List of Applicants
			<small></small>
		  </h1>
		  <ol class="breadcrumb">
			<li><a href="/tabrilya/"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li><a href="/tabrilya/view-academic-year.php">Academic Year</a></li>
			<li><a href="/tabrilya/view-admission.php?academic_year=<?php echo date_format(date_create($row['admission_date']),"Y");?>">Admission Schedules</a></li>
			<li class="active">List of Applicants</li>
		  </ol>
		</section>
		<!-- /.content -->
		    <!-- Main content -->
			
		<section class="content animated fadeIn">
		
		 <div class="box">
		 
				<!-- BOX Header -->
				<div class="box-header with-border">
				  <h3 class="box-title"><span class="fa fa-edit fa-fw"></span> Applicants of <?php echo date_format(date_create($row['admission_date']),"F d, Y - l");?></h3>
				</div>	
				
			<div class="box-body">
			
			<div class="col-md-12">
				<div class="pull-right">
				  <span class="btn btn-app bt-flat bg-navy" data-toggle="modal" data-target="#add-applicant-batch">
					<i class="fa fa-user-plus"></i> Add Applicant
				  </span>
				  <span class="btn btn-app bt-flat bg-olive" onclick="update_applicant_table()">
					<i class="fa fa-upload"></i> Upload CSV
				  </span>
				 </div>
			</div>
			
				<!-- Table -->
				  <table id="applicants-data-table" class="table table-bordered table-striped table-hover text-center">
					<thead>
					<tr>
					  <th colspan="5">Applicant's Info</th>
					  <th colspan="8" class="white-text teal darken-3">SCORE (DAT)</th>
					</tr>
					
					<tr class="teal lighten-5">
					  <th>No.</th>
					  <th>Examinees No.</th>
					  <th>Name</th>
					  <th>Course Applied</th>
					  <th>School</th>

					<?php
 						$q = "SELECT * from dat ORDER BY dat_id";
						$r = mysqli_query($conn,$q);
						while($dat = mysqli_fetch_assoc($r)){
						echo "<th title='".$dat['dat_name']." (".$dat['dat_items']." items)"."'>".$dat['dat_shortname']."</th>";
						}
					?>
						<th>Action</th>
					</tr>
					</thead>
						<tbody>
						<?php
									$applicant_query = mysqli_query($conn,"SELECT applicant_id,school_id,course_id,applicant_exam_no,concat(applicant_fname,' ',applicant_lname) as applicant_name from applicant_info WHERE admission_schedule_id=".$_GET['admission_schedule_id']." ORDER BY applicant_id desc" );
									$rowNum = 0;
									while($applicant_row = mysqli_fetch_array($applicant_query)){
										$rowNum++;
										$school_row = mysqli_fetch_array(mysqli_query($conn,"SELECT school_shortname FROM school WHERE school_id=".$applicant_row['school_id']));
										$course_row = mysqli_fetch_array(mysqli_query($conn,"SELECT course_shortname FROM course WHERE course_id=".$applicant_row['course_id']));
										echo "<tr>
										<td>".$rowNum.".</td>
										<td>".$applicant_row['applicant_exam_no']."</td>
										<td>".$applicant_row['applicant_name']."</td>
										<td>".$course_row['course_shortname']."</td>
										<td>".$school_row['school_shortname']."</td>";
										$score_q = mysqli_query($conn,"SELECT score from scores WHERE applicant_id=".$applicant_row['applicant_id']);
										while($score_row = mysqli_fetch_array($score_q)){
											echo "<td>".$score_row['score']."</td>";
										}
										echo "<td>
										<span title='Edit' class='btn btn-warning btn-sm btn-flat' onclick='getEditModal_applicant(".$applicant_row['applicant_id'].")'><i class='fa fa-edit fa-fw'></i></span>
										<a href='applicant-result.php?applicant_id=".$applicant_row['applicant_id']."&admission_schedule_id=".$_GET['admission_schedule_id']."'><span title='Analyse' class='btn btn-primary btn-sm btn-flat'><i class='fa fa- fa-lightbulb-o fa-fw'></i></span></a>
										</td>";
										echo "</tr>";
									}

						?>
						</tbody>
				  </table>
				  <!-- /.Table -->
		    </div>
			
		 </div>
		   
		</section>
	
	  </div>
	  <!-- /.content-wrapper -->

	<?php include('tags/footer.php');?>

	<?php include('tags/control-sidebar.php');?>

 
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- DataTables ColReorder-->
<script src="bower_components/datatables.net-bs/js/dataTables.colReorder.min.js"></script>
<!-- Morris.js charts -->
<script src="bower_components/raphael/raphael.min.js"></script>
<script src="bower_components/morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="bower_components/moment/min/moment.min.js"></script>
<script src="bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- Generate MD5 -->
<script src="dist/js/generateMD5.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- PACE -->
<script src="bower_components/PACE/pace.min.js"></script>
<!--scrolling js-->
<script src="bower_components/nicescroll/jquery.nicescroll.js"></script>
<script src="bower_components/nicescroll/scripts.js"></script>
<!--//scrolling js-->

<script>
$(document).ajaxStart(function() { Pace.restart(); });

    //Initialize Select2 Elements
    $('.select2').select2();
	
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,
	  format: 'yyyy-mm-dd'
    })
  
 /* jQueryKnob */
 $(function () {
    /* jQueryKnob */

    $(".knob").knob({
      /*change : function (value) {
       //console.log("change : " + value);
       },
       release : function (value) {
       console.log("release : " + value);
       },
       cancel : function () {
       console.log("cancel : " + this.value);
       },*/
      draw: function () {

        // "tron" case
        if (this.$.data('skin') == 'tron') {

          var a = this.angle(this.cv)  // Angle
              , sa = this.startAngle          // Previous start angle
              , sat = this.startAngle         // Start angle
              , ea                            // Previous end angle
              , eat = sat + a                 // End angle
              , r = true;

          this.g.lineWidth = this.lineWidth;

          this.o.cursor
          && (sat = eat - 0.3)
          && (eat = eat + 0.3);

          if (this.o.displayPrevious) {
            ea = this.startAngle + this.angle(this.value);
            this.o.cursor
            && (sa = ea - 0.3)
            && (ea = ea + 0.3);
            this.g.beginPath();
            this.g.strokeStyle = this.previousColor;
            this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sa, ea, false);
            this.g.stroke();
          }

          this.g.beginPath();
          this.g.strokeStyle = r ? this.o.fgColor : this.fgColor;
          this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, sat, eat, false);
          this.g.stroke();

          this.g.lineWidth = 2;
          this.g.beginPath();
          this.g.strokeStyle = this.o.fgColor;
          this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + this.lineWidth * 2 / 3, 0, 2 * Math.PI, false);
          this.g.stroke();

          return false;
        }
      }
    });
    /* END JQUERY KNOB */
 });
  
  
 //admission DataTable ini	
applicant_DT_ini();
function applicant_DT_ini(){
	$('#applicants-data-table').DataTable( {
      'paging'      : true,
	  'paginationType': "full_numbers",
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false,
	  'language'	: {
				   search: "<span class='fa fa-search'></span>",
        searchPlaceholder: "Search.."
					},
	  'columnDefs'	: [ {"targets": [5,6,7,8,9,10,11,12],"orderable": false}],
	  'responsive'	: true
	}	
	);
	$('div.dataTables_filter input').removeClass('input-sm');
	$('div.dataTables_length select').removeClass('input-sm');
}

//AJAX to get applicant edit Modal
function getEditModal_applicant(id){
	$.ajax({
	type: "POST", url: "functions/get_applicant_edit_modal.php", data: "applicant_id="+id, cache: false,
	success: function(response)
	{ 
		$('#edit-applicant-batch .modal-body').html(response);
		$('#edit-applicant-batch').modal();
	}
	});
}


//AJAX to check date if exist
 function check_date(){
 var values = $('#create-batch-form').serialize();
 if(<?php echo json_encode($_SESSION['cps_pass']); ?> == MD5($('#create-batch-userpassword').val())){
	$.ajax({
	type: "POST", url: "functions/check_date_exist.php", data: values, dataType: 'JSON', cache: false,
	success: function(response)
	{ 
		if(response.status == 'fail'){
				$('.check-date-alert').fadeIn('fast',function(){
					$('.check-date-alert span').text(response.message);		
				});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
		}
		else if (response.status == "success") {		
			location.href = response.message;
		}

	}
	});
	}
	else{
			$('.check-date-alert').fadeIn('fast',function(){
				$('.check-date-alert span').text("Password Mismatch");		
			});
			$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
				$(".alert-dismissible").css('display:none');
			});
	}
	
}

//AJAX to add Applicant
$("#add-applicant-form").on('submit', function(e) {
    e.preventDefault();
	var values = $('#add-applicant-form').serialize(); values+="&admission_schedule_id="+<?php echo json_encode($_GET['admission_schedule_id']); ?>;
 	$.ajax({
	type: "POST", url: "functions/add-applicant.php", data: values, dataType: 'JSON', cache: false,
	success: function(response)
	{ 
		if (response.status == "success") {		
				$('.success-add-applicant-alert').fadeIn('fast',function(){
					$('.success-add-applicant-alert span').text(response.message);		
				});
				$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
					$(".alert-dismissible").css('display:none');
				});
				$('#add-applicant-form')[0].reset();
				update_applicant_table();
		}
	}
	});
}); 


//AJAX to Edit Applicant
$("#edit-applicant-form").on('submit', function(e) {
    e.preventDefault();
	var values = $('#edit-applicant-form').serialize(); values+="&admission_schedule_id="+<?php echo json_encode($_GET['admission_schedule_id']); ?>;
 	$.ajax({
	type: "POST", url: "functions/edit-applicant.php", data: values, dataType: 'JSON', cache: false,
	success: function(response)
	{ 
		if (response.status == "success") {		
				$('.success-add-applicant-alert').fadeIn('fast',function(){
					$('.success-add-applicant-alert span').text(response.message);		
				});
				$(".alert-dismissible").fadeTo(2000, 500).slideUp(500, function(){
					$(".alert-dismissible").css('display:none');
				});
				update_applicant_table();
		}
	}
	});
}); 


//AJAX to update applicants table
 function update_applicant_table(){
 var values = "admission_schedule_id="+<?php echo json_encode($_GET['admission_schedule_id']); ?>;
 	$.ajax({
	type: "POST", url: "functions/get-applicant-table-data.php", data: values, cache: false,
	success: function(response)
	{
		var search_DT_value = $('.dataTables_filter input').val();
		var page_DT_value = $('#applicants-data-table').DataTable().page();
		$('#applicants-data-table').dataTable().fnDestroy();
		$('#applicants-data-table tbody').html(response);
		applicant_DT_ini();
		$('#applicants-data-table').DataTable().search( search_DT_value ).draw();
		$('#applicants-data-table').DataTable().page( page_DT_value ).draw( 'page' );
		
	}
	});
}
//iCheck
$(function () {
$('#logoutcheckbox').on('ifChanged', function(event){                
      if(event.type ==="ifChanged"){
			$('#logoutform').submit();
           }                             
      }).iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });

  //iCheck
$(function () {
$('#gender_1, #gender_2').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });


</script>

</body>
</html>