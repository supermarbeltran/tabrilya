<?php
function _sqlInsert($table,$values) {

	$connect = db_connect();
	$query = "Insert into ".$table."  values('',".$values.")";
	
	$result = mysqli_query($connect,$query)or die(mysqli_error($connect));
	
	return $result;

		
}

/*	returns 
 *	an array
 *	data
 */
function db_res_to_array($result)
{
	$connect=db_connect();
	$res_to_array = array();
	
	for($count=0;$row = mysqli_fetch_array($result);$count++)
	{
		$res_to_array[$count] = $row;
	
	}
	
	return $result;
	
}

/*	function 
 *	for selecting data
 *	to all tables
 */
function _sqlSelect($table){

	$connect=db_connect();
	$query = "Select * from ".$table." ";
	
	$result = mysqli_query($connect,$query);
	$result = db_res_to_array($result);
	
	return $result;
}




/*	function 
 *	for retrieving data
 *	in contestants table last insert id
 */
function _sqlQuerySelectLast($table,$column,$last){
	$connect=db_connect();
	$query = "Select * from ".$table." where ".$column." =  '".$last."'";
	
	$result = mysqli_query($connect,$query);
	$result = mysqli_fetch_assoc($result);
	
	return $result;
}

/*	function 
 *	for retrieving data
 *	where id = $id
 */
function _sqlQuerySelectAll($table,$column,$id){
	$connect=db_connect();
	$query = "Select * from ".$table." where ".$column." =  '".$id."'";
	
	$result = mysqli_query($connect,$query);
	$result = db_res_to_array($result);
	
	return $result;
}

function _sqlQuerySelectByOrder2($table,$column,$id,$column2,$val){
	$connect=db_connect();
	$query = "Select * from ".$table." where ".$column." =  '".$id."' AND is_active = 'YES' ORDER BY ".$column2." ".$val."";
	
	$result = mysqli_query($connect,$query);
	$result = db_res_to_array($result);
	
	return $result;
}

function updateAll($table,$column,$condition){
	
	$connect=db_connect();
	$query = "Update ".$table." SET ".$column." ".$condition." ";
	
	$result = mysqli_query($connect,$query)or die(mysqli_error($connect));
	
	return $result;

}

/*	function 
 *	for encrypting data
 *	withtime stamp;
 */

function  _deleteImage($file){
	$filename = 'upload_image/'.$file;
	unlink($filename);

}

function _sqlDelete($table,$column,$id){
	$connect=db_connect();
	mysqli_query($connect,"Delete from ".$table." where ".$column." =  '".$id."'");

	
	
	$result = mysqli_affected_rows($connect);
	
	
	return $result;

}

function _md5($url){
	
	$encrypt = md5($url.time());
	
	return $encrypt;
	
}



?>